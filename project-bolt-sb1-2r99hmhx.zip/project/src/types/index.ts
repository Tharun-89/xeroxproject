export interface FileUpload {
  file: File;
  pageCount: number;
  name: string;
}

export interface CartItem {
  id: string;
  serviceName: string;
  fileName: string;
  pageCount: number;
  options: any;
  price: number;
  timestamp: Date;
}

export interface Order {
  id: string;
  items: CartItem[];
  totalAmount: number;
  customerInfo?: {
    name: string;
    phone: string;
    email: string;
  };
  timestamp: Date;
  status: 'pending' | 'completed' | 'cancelled';
}

export type ServiceType = 'printing' | 'spiral-binding' | 'soft-binding' | 'custom-printing' | 'color-custom';
export type PageType = 'home' | 'services' | 'about' | 'contact' | 'cart' | 'admin' | 'admin-dashboard' | ServiceType;