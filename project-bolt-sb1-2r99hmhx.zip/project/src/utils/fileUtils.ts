import * as pdfjsLib from 'pdfjs-dist';

// Set up PDF.js worker
pdfjsLib.GlobalWorkerOptions.workerSrc = `//cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js`;

export const detectPageCount = async (file: File): Promise<number> => {
  try {
    if (file.type === 'application/pdf') {
      return await detectPDFPageCount(file);
    } else if (file.type.includes('word') || file.name.endsWith('.docx') || file.name.endsWith('.doc')) {
      return await detectWordPageCount(file);
    }
    
    // Default to 1 page for other file types
    return 1;
  } catch (error) {
    console.error('Error detecting page count:', error);
    // Return 1 as fallback and show warning
    return 1;
  }
};

const detectPDFPageCount = async (file: File): Promise<number> => {
  try {
    const arrayBuffer = await file.arrayBuffer();
    const pdf = await pdfjsLib.getDocument({ data: arrayBuffer }).promise;
    return pdf.numPages;
  } catch (error) {
    console.error('Error reading PDF:', error);
    throw new Error('Unable to read PDF file');
  }
};

const detectWordPageCount = async (file: File): Promise<number> => {
  try {
    // For DOCX files, we'll estimate based on file size and content
    const sizeInMB = file.size / (1024 * 1024);
    
    if (file.name.endsWith('.docx')) {
      // Read DOCX as ZIP and try to extract content
      const arrayBuffer = await file.arrayBuffer();
      const text = await extractTextFromDocx(arrayBuffer);
      
      // Estimate pages based on character count
      // Rough estimate: ~2000 characters per page
      const estimatedPages = Math.max(1, Math.ceil(text.length / 2000));
      return estimatedPages;
    } else {
      // For .doc files, estimate based on file size
      // Rough estimate: 1 page ≈ 0.05MB for Word docs
      return Math.max(1, Math.round(sizeInMB / 0.05));
    }
  } catch (error) {
    console.error('Error reading Word document:', error);
    // Fallback to size-based estimation
    const sizeInMB = file.size / (1024 * 1024);
    return Math.max(1, Math.round(sizeInMB / 0.05));
  }
};

const extractTextFromDocx = async (arrayBuffer: ArrayBuffer): Promise<string> => {
  try {
    // Simple DOCX text extraction (basic implementation)
    // In production, you might want to use a proper DOCX parser library
    const uint8Array = new Uint8Array(arrayBuffer);
    const text = new TextDecoder().decode(uint8Array);
    
    // Extract readable text (very basic approach)
    const readableText = text.replace(/[^\x20-\x7E]/g, ' ').replace(/\s+/g, ' ').trim();
    return readableText;
  } catch (error) {
    console.error('Error extracting text from DOCX:', error);
    return '';
  }
};

export const isValidFileType = (file: File): boolean => {
  const validTypes = [
    'application/pdf',
    'application/msword',
    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
    'text/plain'
  ];
  
  const validExtensions = ['.pdf', '.doc', '.docx'];
  
  return validTypes.includes(file.type) || 
         validExtensions.some(ext => file.name.toLowerCase().endsWith(ext));
};

export const formatFileSize = (bytes: number): string => {
  if (bytes === 0) return '0 Bytes';
  
  const k = 1024;
  const sizes = ['Bytes', 'KB', 'MB', 'GB'];
  const i = Math.floor(Math.log(bytes) / Math.log(k));
  
  return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
};