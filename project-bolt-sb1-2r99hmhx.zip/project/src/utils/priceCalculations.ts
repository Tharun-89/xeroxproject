export const calculatePrintingPrice = (
  pages: number,
  printType: string,
  copies: number = 1
): number => {
  let pricePerPage = 0;
  let effectivePages = pages;

  switch (printType) {
    case 'bw-single':
      pricePerPage = 1.5; // ₹1.5 per page
      break;
    case 'bw-double':
      pricePerPage = 1.7; // ₹1.7 per sheet
      effectivePages = Math.ceil(pages / 2); // pages / 2, rounded up
      break;
    case 'color-single':
      pricePerPage = 8; // ₹8 per page
      break;
    case 'color-double':
      pricePerPage = 12; // ₹12 per sheet
      effectivePages = Math.ceil(pages / 2); // pages / 2, rounded up
      break;
    default:
      return 0;
  }

  return effectivePages * pricePerPage * copies;
};

export const calculateSpiralBindingPrice = (pages: number, isDoubleSide: boolean = false): number => {
  const effectivePages = isDoubleSide ? Math.ceil(pages / 2) : pages;
  
  if (effectivePages <= 60) return 25;
  if (effectivePages <= 100) return 30;
  if (effectivePages <= 120) return 35;
  if (effectivePages <= 140) return 40;
  if (effectivePages <= 160) return 45;
  
  // For pages beyond 160, add ₹5 for every 20 extra pages
  const extraPages = effectivePages - 160;
  const extraSets = Math.ceil(extraPages / 20);
  return 45 + (extraSets * 5);
};

export const calculateSoftBindingPrice = (
  pages: number,
  printType: string,
  copies: number = 1
): number => {
  const printPrice = calculatePrintingPrice(pages, printType, copies);
  const bindingCharge = 25 * copies;
  return printPrice + bindingCharge;
};

export const calculateCustomPrintingPrice = (
  pages: number,
  customType: string,
  isDoubleSide: boolean,
  copies: number
): number => {
  let pricePerPage = 0;
  let divisor = 1;

  switch (customType) {
    case '4-in-1':
      divisor = isDoubleSide ? 8 : 4;
      pricePerPage = 1.7;
      break;
    case '8-in-1':
      divisor = isDoubleSide ? 16 : 8;
      pricePerPage = isDoubleSide ? 5 : 3;
      break;
    case '9-in-1':
      divisor = isDoubleSide ? 18 : 9;
      pricePerPage = isDoubleSide ? 5 : 3;
      break;
    default:
      return 0;
  }

  const effectivePages = Math.ceil(pages / divisor);
  return effectivePages * pricePerPage * copies;
};

export const calculateColorCustomPrice = (
  totalPages: number,
  colorPages: number,
  printType: string,
  copies: number = 1
): number => {
  const bwPages = totalPages - colorPages;
  let colorRate = 8;
  let bwRate = 1.5;
  let effectiveColorPages = colorPages;
  let effectiveBwPages = bwPages;

  if (printType === 'double') {
    colorRate = 12;
    bwRate = 1.7;
    effectiveColorPages = Math.ceil(colorPages / 2);
    effectiveBwPages = Math.ceil(bwPages / 2);
  }

  return (effectiveColorPages * colorRate + effectiveBwPages * bwRate) * copies;
};

export const parseColorPageRange = (input: string): number => {
  if (!input.trim()) return 0;
  
  const ranges = input.split(',').map(s => s.trim());
  const pages = new Set<number>();
  
  ranges.forEach(range => {
    if (range.includes('-')) {
      const [start, end] = range.split('-').map(n => parseInt(n.trim()));
      if (!isNaN(start) && !isNaN(end)) {
        for (let i = start; i <= end; i++) {
          pages.add(i);
        }
      }
    } else {
      const pageNum = parseInt(range);
      if (!isNaN(pageNum)) {
        pages.add(pageNum);
      }
    }
  });
  
  return pages.size;
};

// Custom Color Pricing for Printing Service
export const calculateCustomColorPrintingPrice = (
  totalPages: number,
  colorPageInput: string,
  sideType: string,
  copies: number = 1
): number => {
  const colorPages = parseColorPageRange(colorPageInput);
  const bwPages = totalPages - colorPages;
  
  let colorRate = 8; // ₹8 per page
  let bwRate = 1.5; // ₹1.5 per page
  let effectiveColorPages = colorPages;
  let effectiveBwPages = bwPages;

  if (sideType === 'double') {
    colorRate = 12; // ₹12 per sheet
    bwRate = 1.7; // ₹1.7 per sheet
    effectiveColorPages = Math.ceil(colorPages / 2);
    effectiveBwPages = Math.ceil(bwPages / 2);
  }

  return (effectiveColorPages * colorRate + effectiveBwPages * bwRate) * copies;
};

// Custom Color Pricing for Spiral Binding
export const calculateCustomColorSpiralBindingPrice = (
  totalPages: number,
  colorPageInput: string,
  sideType: string,
  copies: number = 1
): number => {
  const printPrice = calculateCustomColorPrintingPrice(totalPages, colorPageInput, sideType, copies);
  const bindingPrice = calculateSpiralBindingPrice(totalPages, sideType === 'double') * copies;
  return printPrice + bindingPrice;
};

// Custom Color Pricing for Soft Binding
export const calculateCustomColorSoftBindingPrice = (
  totalPages: number,
  colorPageInput: string,
  sideType: string,
  copies: number = 1
): number => {
  const printPrice = calculateCustomColorPrintingPrice(totalPages, colorPageInput, sideType, copies);
  const bindingCharge = 25 * copies;
  return printPrice + bindingCharge;
};

// Validation function for page range input
export const validatePageRange = (input: string, totalPages: number): { isValid: boolean; error?: string } => {
  if (!input.trim()) {
    return { isValid: false, error: 'Please enter page numbers' };
  }

  const ranges = input.split(',').map(s => s.trim());
  
  for (const range of ranges) {
    if (range.includes('-')) {
      const [start, end] = range.split('-').map(n => parseInt(n.trim()));
      if (isNaN(start) || isNaN(end)) {
        return { isValid: false, error: 'Invalid page format. Use: 1-5,6,9' };
      }
      if (start > end) {
        return { isValid: false, error: 'Start page cannot be greater than end page' };
      }
      if (start < 1 || end > totalPages) {
        return { isValid: false, error: `Page numbers must be between 1 and ${totalPages}` };
      }
    } else {
      const pageNum = parseInt(range);
      if (isNaN(pageNum)) {
        return { isValid: false, error: 'Invalid page format. Use: 1-5,6,9' };
      }
      if (pageNum < 1 || pageNum > totalPages) {
        return { isValid: false, error: `Page numbers must be between 1 and ${totalPages}` };
      }
    }
  }

  return { isValid: true };
};