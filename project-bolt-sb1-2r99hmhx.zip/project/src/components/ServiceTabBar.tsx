import React from 'react';
import { Printer, BookOpen, FileText, Palette, GraduationCap, Camera } from 'lucide-react';
import { PageType } from '../types';

interface ServiceTabBarProps {
  currentPage: PageType;
  onNavigate: (page: PageType) => void;
}

const ServiceTabBar: React.FC<ServiceTabBarProps> = ({ currentPage, onNavigate }) => {
  const tabs = [
    {
      id: 'printing' as PageType,
      label: 'Printing',
      icon: Printer,
      available: true
    },
    {
      id: 'spiral-binding' as PageType,
      label: 'Spiral',
      icon: BookOpen,
      available: true
    },
    {
      id: 'soft-binding' as PageType,
      label: 'Soft',
      icon: FileText,
      available: true
    },
    {
      id: 'custom-printing' as PageType,
      label: 'Custom',
      icon: Palette,
      available: true
    },
    {
      id: 'thesis-binding' as PageType,
      label: 'Thesis',
      icon: GraduationCap,
      available: false
    },
    {
      id: 'photo-frames' as PageType,
      label: 'Photo',
      icon: Camera,
      available: false
    }
  ];

  return (
    <div className="w-full bg-gray-50 py-6">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Tab Container */}
        <div className="bg-white rounded-2xl shadow-lg p-2 max-w-3xl mx-auto animate-fade-in">
          <div className="flex overflow-x-auto scrollbar-hide">
            <div className="flex space-x-1 min-w-max mx-auto">
              {tabs.map((tab, index) => {
                const Icon = tab.icon;
                const isActive = currentPage === tab.id;
                
                return (
                  <button
                    key={tab.id}
                    onClick={() => tab.available && onNavigate(tab.id)}
                    disabled={!tab.available}
                    className={`
                      flex items-center space-x-2 px-4 py-2 rounded-xl font-medium text-sm
                      transition-all duration-300 transform hover:scale-105
                      min-w-max h-10
                      ${isActive 
                        ? 'bg-blue-600 text-white shadow-md' 
                        : tab.available
                          ? 'text-gray-700 hover:bg-blue-50 hover:text-blue-600 hover:shadow-sm border border-gray-200'
                          : 'text-gray-400 cursor-not-allowed opacity-60'
                      }
                      ${tab.available ? 'hover:shadow-lg' : ''}
                    `}
                    style={{ 
                      animationDelay: `${index * 100}ms`,
                      animationFillMode: 'both'
                    }}
                  >
                    <Icon className="w-4 h-4 flex-shrink-0" />
                    <span className="whitespace-nowrap">{tab.label}</span>
                    {!tab.available && (
                      <span className="text-xs bg-gray-200 text-gray-600 px-2 py-0.5 rounded-full ml-1">
                        Soon
                      </span>
                    )}
                  </button>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ServiceTabBar;