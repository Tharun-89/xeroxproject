import React from 'react';
import { Phone, Mail, MapPin, Clock, Send, MessageCircle, User, Building, Globe } from 'lucide-react';

const ContactUs: React.FC = () => {
  const handleSendMessage = () => {
    const email = 'aishwaryaxerox1999@gmail.com';
    const subject = 'Inquiry from Website';
    const body = 'Hello Aishwarya Xerox,\n\nI would like to inquire about your services.\n\nBest regards,';
    
    const mailtoLink = `mailto:${email}?subject=${encodeURIComponent(subject)}&body=${encodeURIComponent(body)}`;
    window.location.href = mailtoLink;
  };

  const contactMethods = [
    {
      icon: Phone,
      title: 'Call Us',
      primary: '+91 6301526803',
      secondary: 'Mon–Sat: 8:30 AM – 9:30 PM\nSun: 11:00 AM – 9:30 PM',
      description: 'Call us for immediate assistance',
      color: 'blue'
    },
    {
      icon: Mail,
      title: 'Email Us',
      primary: 'aishwaryaxerox1999@gmail.com',
      secondary: 'We reply within 24 hours',
      description: 'Send us your queries anytime',
      color: 'green'
    },
    {
      icon: MapPin,
      title: 'Visit Us',
      primary: 'ADB road, near Pragati Engineering College',
      secondary: 'Surampalem, Ramesampeta, 533437, AP',
      description: 'Visit us at our location',
      color: 'purple'
    }
  ];

  const businessInfo = [
    {
      icon: Building,
      title: 'Business Hours',
      details: [
        'Monday - Saturday: 8:30 AM - 9:30 PM',
        'Sunday: 11:00 AM - 9:30 PM',
        'Open 7 days a week'
      ]
    },
    {
      icon: Globe,
      title: 'Service Area',
      details: [
        'Surampalem & surrounding areas',
        'Pragati Engineering College vicinity',
        'East Godavari District'
      ]
    },
    {
      icon: User,
      title: 'Customer Support',
      details: [
        'Instant response during business hours',
        'Call within 10 minutes of order',
        'Dedicated customer service'
      ]
    }
  ];

  const services = [
    { name: 'Printing', icon: '🖨️' },
    { name: 'Spiral Binding', icon: '📚' },
    { name: 'Soft Binding', icon: '📄' },
    { name: 'Custom Printing', icon: '🎨' }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header Section */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
          <div className="text-center">
            <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">Contact Us</h1>
            <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
              Get in touch with us for any queries or support. We're here to help you with 
              all your printing and binding needs!
            </p>
          </div>
        </div>
      </div>

      {/* Main Contact Methods */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Get In Touch</h2>
            <p className="text-xl text-gray-600">Choose your preferred way to reach us</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {contactMethods.map((method, index) => {
              const Icon = method.icon;
              const colorClasses = {
                blue: 'bg-blue-100 text-blue-600 border-blue-200',
                green: 'bg-green-100 text-green-600 border-green-200',
                purple: 'bg-purple-100 text-purple-600 border-purple-200'
              };

              return (
                <div key={index} className="bg-white rounded-2xl shadow-xl p-8 text-center transform hover:scale-105 transition-all duration-300">
                  <div className={`w-16 h-16 rounded-full ${colorClasses[method.color as keyof typeof colorClasses]} flex items-center justify-center mx-auto mb-6`}>
                    <Icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-3">{method.title}</h3>
                  <p className="text-lg font-semibold text-gray-800 mb-2">{method.primary}</p>
                  <p className="text-gray-600 whitespace-pre-line mb-3">{method.secondary}</p>
                  <p className="text-sm text-gray-500">{method.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Business Information */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Business Information</h2>
            <p className="text-xl text-gray-600">Everything you need to know about our services</p>
          </div>

          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
            {businessInfo.map((info, index) => {
              const Icon = info.icon;
              return (
                <div key={index} className="bg-white rounded-2xl shadow-lg p-8 text-center">
                  <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                    <Icon className="w-8 h-8 text-gray-600" />
                  </div>
                  <h3 className="text-xl font-bold text-gray-900 mb-4">{info.title}</h3>
                  <div className="space-y-2">
                    {info.details.map((detail, idx) => (
                      <p key={idx} className="text-gray-600">{detail}</p>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        </div>
      </div>

      {/* Services Overview */}
      <div className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Our Services</h2>
            <p className="text-xl text-gray-600">Professional printing and binding solutions</p>
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {services.map((service, index) => (
              <div key={index} className="bg-gray-50 rounded-xl shadow-lg p-6 text-center transform hover:scale-105 transition-all duration-300">
                <div className="text-4xl mb-3">{service.icon}</div>
                <h3 className="font-semibold text-gray-900">{service.name}</h3>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Quick Message Section */}
      <div className="py-16 bg-gray-50">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-gradient-to-r from-blue-600 to-indigo-700 rounded-2xl shadow-xl p-8 md:p-12 text-white text-center">
            <MessageCircle className="w-16 h-16 mx-auto mb-6 text-blue-100" />
            <h3 className="text-2xl md:text-3xl font-bold mb-4">Send us a message</h3>
            <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
              Click the button below to open your email client and send us a message directly. 
              We'll get back to you as soon as possible!
            </p>
            <button
              onClick={handleSendMessage}
              className="bg-white text-blue-600 px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-all duration-300 transform hover:scale-105 flex items-center space-x-3 mx-auto shadow-lg"
            >
              <Send className="w-6 h-6" />
              <span>Send Message</span>
            </button>
          </div>
        </div>
      </div>

      {/* Emergency Contact */}
      <div className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-red-50 border-2 border-red-200 rounded-2xl p-8 text-center">
            <div className="w-16 h-16 bg-red-100 rounded-full flex items-center justify-center mx-auto mb-6">
              <Phone className="w-8 h-8 text-red-600" />
            </div>
            <h4 className="text-xl font-bold text-red-900 mb-3">Emergency Contact</h4>
            <p className="text-red-700 mb-4">
              For urgent printing needs outside business hours, please call:
            </p>
            <p className="text-2xl font-bold text-red-900 mb-2">6301526803</p>
            <p className="text-red-600 text-sm">
              *Additional charges may apply for emergency services
            </p>
          </div>
        </div>
      </div>

      {/* Footer CTA */}
      <div className="py-16 bg-gradient-to-r from-blue-600 to-indigo-700">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">Ready to Get Started?</h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Experience the difference of working with a trusted printing partner. 
            Contact us today for all your printing and binding needs.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <div className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold shadow-lg">
              📞 6301526803
            </div>
            <div className="bg-white text-blue-600 px-8 py-3 rounded-lg font-semibold shadow-lg">
              ✉️ aishwaryaxerox1999@gmail.com
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ContactUs;