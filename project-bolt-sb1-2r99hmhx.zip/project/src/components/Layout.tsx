import React, { useState, useRef, useEffect } from 'react';
import { Menu, X, ChevronDown, User, ShoppingCart, Database } from 'lucide-react';
import { PageType } from '../types';

interface LayoutProps {
  children: React.ReactNode;
  currentPage: PageType;
  onNavigate: (page: PageType) => void;
  cartItemCount: number;
}

const Layout: React.FC<LayoutProps> = ({ children, currentPage, onNavigate, cartItemCount }) => {
  const [isMenuOpen, setIsMenuOpen] = useState(false);
  const [isServicesDropdownOpen, setIsServicesDropdownOpen] = useState(false);
  const [isUserDropdownOpen, setIsUserDropdownOpen] = useState(false);
  const servicesDropdownRef = useRef<HTMLDivElement>(null);
  const userDropdownRef = useRef<HTMLDivElement>(null);

  const navigation = [
    { name: 'Home', page: 'home' as PageType },
    { 
      name: 'Services', 
      page: 'services' as PageType,
      hasDropdown: true,
      dropdownItems: [
        { name: 'Printing', page: 'printing' as PageType },
        { name: 'Spiral Binding', page: 'spiral-binding' as PageType },
        { name: 'Soft Binding', page: 'soft-binding' as PageType },
        { name: 'Custom Printing', page: 'custom-printing' as PageType }
      ]
    },
    { name: 'About Us', page: 'about' as PageType },
    { name: 'Contact', page: 'contact' as PageType }
  ];

  // Close dropdowns when clicking outside
  useEffect(() => {
    const handleClickOutside = (event: MouseEvent) => {
      if (servicesDropdownRef.current && !servicesDropdownRef.current.contains(event.target as Node)) {
        setIsServicesDropdownOpen(false);
      }
      if (userDropdownRef.current && !userDropdownRef.current.contains(event.target as Node)) {
        setIsUserDropdownOpen(false);
      }
    };

    document.addEventListener('mousedown', handleClickOutside);
    return () => {
      document.removeEventListener('mousedown', handleClickOutside);
    };
  }, []);

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Fixed Header */}
      <header className="bg-white border-b border-gray-200 fixed top-0 left-0 right-0 z-50" style={{ height: '60px' }}>
        <div className="max-w-7xl mx-auto px-5 h-full">
          <div className="flex justify-between items-center h-full">
            {/* Logo Section - Left Side */}
            <div className="flex items-center space-x-3 cursor-pointer" onClick={() => onNavigate('home')}>
              <img
                src="https://ucarecdn.com/d78983ef-713c-414c-b497-98e6cc0bae09/Untitleddesign1.svg"
                alt="Aishwarya Xerox Logo"
                className="h-8 w-auto"
              />
              <div className="flex flex-col">
                <h1 className="text-lg font-bold text-black leading-tight">Aishwarya Xerox</h1>
                <p className="text-xs text-gray-500 leading-tight">Fast & Reliable Printing</p>
              </div>
            </div>

            {/* Desktop Navigation - Right Side */}
            <nav className="hidden lg:flex items-center space-x-6">
              {navigation.map((item) => (
                <div key={item.name} className="relative" ref={item.hasDropdown ? servicesDropdownRef : undefined}>
                  {item.hasDropdown ? (
                    <div className="relative">
                      <button
                        onClick={() => setIsServicesDropdownOpen(!isServicesDropdownOpen)}
                        className={`flex items-center space-x-1 px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                          currentPage === item.page || ['printing', 'spiral-binding', 'soft-binding', 'custom-printing', 'color-custom'].includes(currentPage)
                            ? 'text-blue-600 bg-blue-50'
                            : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                        }`}
                      >
                        <span>{item.name}</span>
                        <ChevronDown className={`w-4 h-4 transition-transform duration-200 ${isServicesDropdownOpen ? 'rotate-180' : ''}`} />
                      </button>
                      
                      {isServicesDropdownOpen && (
                        <div className="absolute top-full left-0 mt-1 w-48 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                          {item.dropdownItems?.map((dropdownItem) => (
                            <button
                              key={dropdownItem.name}
                              onClick={() => {
                                onNavigate(dropdownItem.page);
                                setIsServicesDropdownOpen(false);
                              }}
                              className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                            >
                              {dropdownItem.name}
                            </button>
                          ))}
                        </div>
                      )}
                    </div>
                  ) : (
                    <button
                      onClick={() => onNavigate(item.page)}
                      className={`px-3 py-2 rounded-md text-sm font-medium transition-all duration-200 ${
                        currentPage === item.page
                          ? 'text-blue-600 bg-blue-50'
                          : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                      }`}
                    >
                      {item.name}
                    </button>
                  )}
                </div>
              ))}
              
              {/* Cart Icon */}
              <button
                onClick={() => onNavigate('cart')}
                className={`relative p-2 rounded-md transition-all duration-200 ${
                  currentPage === 'cart'
                    ? 'text-blue-600 bg-blue-50'
                    : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                }`}
              >
                <ShoppingCart className="w-5 h-5" />
                {cartItemCount > 0 && (
                  <span className="absolute -top-1 -right-1 bg-red-500 text-white text-xs rounded-full px-1.5 py-0.5 min-w-[18px] h-4 flex items-center justify-center font-medium leading-none">
                    {cartItemCount}
                  </span>
                )}
              </button>

              {/* User Dropdown */}
              <div className="relative" ref={userDropdownRef}>
                <button
                  onClick={() => setIsUserDropdownOpen(!isUserDropdownOpen)}
                  className="flex items-center space-x-2 px-3 py-2 rounded-md text-sm font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 transition-all duration-200"
                >
                  <User className="w-4 h-4" />
                  <span>Admin</span>
                  <ChevronDown className={`w-3 h-3 transition-transform duration-200 ${isUserDropdownOpen ? 'rotate-180' : ''}`} />
                </button>
                
                {isUserDropdownOpen && (
                  <div className="absolute top-full right-0 mt-1 w-44 bg-white rounded-lg shadow-lg border border-gray-200 py-2 z-50">
                    <button
                      onClick={() => {
                        onNavigate('cart');
                        setIsUserDropdownOpen(false);
                      }}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                    >
                      My Orders
                    </button>
                    <button
                      onClick={() => {
                        onNavigate('admin');
                        setIsUserDropdownOpen(false);
                      }}
                      className="block w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                    >
                      Admin Login
                    </button>
                    <button
                      onClick={() => {
                        onNavigate('admin-dashboard');
                        setIsUserDropdownOpen(false);
                      }}
                      className="flex items-center w-full text-left px-4 py-2 text-sm text-gray-700 hover:bg-blue-50 hover:text-blue-600 transition-colors"
                    >
                      <Database className="w-4 h-4 mr-2" />
                      Admin Dashboard
                    </button>
                  </div>
                )}
              </div>
            </nav>

            {/* Mobile menu button */}
            <div className="lg:hidden">
              <button
                onClick={() => setIsMenuOpen(!isMenuOpen)}
                className="text-gray-700 hover:text-blue-600 p-2 transition-colors"
              >
                {isMenuOpen ? <X className="w-6 h-6" /> : <Menu className="w-6 h-6" />}
              </button>
            </div>
          </div>
        </div>

        {/* Mobile Navigation */}
        {isMenuOpen && (
          <div className="lg:hidden bg-white border-t border-gray-200 shadow-lg">
            <div className="px-4 pt-2 pb-3 space-y-1 max-h-96 overflow-y-auto">
              {navigation.map((item) => (
                <div key={item.name}>
                  <button
                    onClick={() => {
                      if (!item.hasDropdown) {
                        onNavigate(item.page);
                        setIsMenuOpen(false);
                      }
                    }}
                    className={`block w-full text-left px-3 py-2 rounded-md text-base font-medium transition-colors ${
                      currentPage === item.page
                        ? 'text-blue-600 bg-blue-50'
                        : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                    }`}
                  >
                    {item.name}
                  </button>
                  {item.hasDropdown && (
                    <div className="ml-4 space-y-1">
                      {item.dropdownItems?.map((dropdownItem) => (
                        <button
                          key={dropdownItem.name}
                          onClick={() => {
                            onNavigate(dropdownItem.page);
                            setIsMenuOpen(false);
                          }}
                          className="block w-full text-left px-3 py-2 rounded-md text-sm text-gray-600 hover:text-blue-600 hover:bg-gray-50 transition-colors"
                        >
                          {dropdownItem.name}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
              ))}
              
              <button
                onClick={() => {
                  onNavigate('cart');
                  setIsMenuOpen(false);
                }}
                className={`flex items-center space-x-2 w-full px-3 py-2 rounded-md text-base font-medium transition-colors ${
                  currentPage === 'cart'
                    ? 'text-blue-600 bg-blue-50'
                    : 'text-gray-700 hover:text-blue-600 hover:bg-gray-50'
                }`}
              >
                <ShoppingCart className="w-5 h-5" />
                <span>Cart</span>
                {cartItemCount > 0 && (
                  <span className="bg-red-500 text-white text-xs rounded-full px-2 py-1 min-w-[20px] h-5 flex items-center justify-center">
                    {cartItemCount}
                  </span>
                )}
              </button>

              <button
                onClick={() => {
                  onNavigate('admin');
                  setIsMenuOpen(false);
                }}
                className="flex items-center space-x-2 w-full px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 transition-colors"
              >
                <User className="w-5 h-5" />
                <span>Admin Login</span>
              </button>

              <button
                onClick={() => {
                  onNavigate('admin-dashboard');
                  setIsMenuOpen(false);
                }}
                className="flex items-center space-x-2 w-full px-3 py-2 rounded-md text-base font-medium text-gray-700 hover:text-blue-600 hover:bg-gray-50 transition-colors"
              >
                <Database className="w-5 h-5" />
                <span>Admin Dashboard</span>
              </button>
            </div>
          </div>
        )}
      </header>

      {/* Main Content with top padding to account for fixed header */}
      <main className="pt-[60px]">
        {children}
      </main>

      {/* Footer */}
      <footer className="bg-[#0D1A3A] text-white">
        <div className="max-w-7xl mx-auto py-12 px-5">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div>
              <h3 className="text-xl font-bold mb-4">Aishwarya Xerox</h3>
              <p className="text-gray-300 leading-relaxed">
                Your trusted partner for all printing and binding needs. Fast, reliable, and affordable services.
              </p>
            </div>
            
            <div>
              <h3 className="text-xl font-bold mb-4">Contact Info</h3>
              <div className="space-y-3 text-gray-300">
                <p className="flex items-center space-x-2">
                  <span>📞</span>
                  <span>6301526803</span>
                </p>
                <p className="flex items-center space-x-2">
                  <span>📧</span>
                  <span>aishwaryaxerox1999@gmail.com</span>
                </p>
                <p className="flex items-start space-x-2">
                  <span>📍</span>
                  <span>ADB road, near Pragati Engineering College, Surampalem, Ramesampeta, 533437</span>
                </p>
              </div>
            </div>
            
            <div>
              <h3 className="text-xl font-bold mb-4">Shop Timings</h3>
              <div className="space-y-2 text-gray-300">
                <p>Mon - Sat: 8:30 AM - 9:30 PM</p>
                <p>Sunday: 11:00 AM - 9:30 PM</p>
              </div>
              
              <div className="mt-6">
                <h4 className="text-lg font-semibold mb-3">Services</h4>
                <div className="space-y-1 text-gray-300 text-sm">
                  <p>• Printing</p>
                  <p>• Spiral Binding</p>
                  <p>• Soft Binding</p>
                  <p>• Custom Printing</p>
                </div>
              </div>
            </div>
          </div>
          
          <div className="mt-8 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>&copy; 2024 Aishwarya Xerox. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Layout;