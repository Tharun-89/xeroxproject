import React, { useState, useRef, useEffect } from 'react';
import { User, Phone, FileText, Calculator, ShoppingCart, Upload, CheckCircle } from 'lucide-react';
import { addOrder } from '../lib/firebase';

// Uploadcare types
declare global {
  interface Window {
    LR: any;
  }
}

const OrderForm: React.FC = () => {
  // Form state
  const [name, setName] = useState('');
  const [phone, setPhone] = useState('');
  const [service, setService] = useState('Printing');
  const [sideType, setSideType] = useState('Single Side');
  const [colorType, setColorType] = useState('Black & White');
  const [copies, setCopies] = useState(1);
  const [pages, setPages] = useState(1);
  const [uploadedFileUrl, setUploadedFileUrl] = useState('');
  const [fileName, setFileName] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [showSuccess, setShowSuccess] = useState(false);

  const uploaderRef = useRef<any>(null);

  // Load Uploadcare script
  useEffect(() => {
    const script = document.createElement('script');
    script.src = 'https://cdn.jsdelivr.net/npm/@uploadcare/blocks@0.35.2/web/lr-file-uploader-regular.min.js';
    script.type = 'module';
    document.head.appendChild(script);

    return () => {
      document.head.removeChild(script);
    };
  }, []);

  // Calculate price based on service and options
  const calculatePrice = () => {
    let basePrice = 0;
    let effectivePages = pages;

    // Calculate print cost
    if (colorType === 'Black & White') {
      if (sideType === 'Single Side') {
        basePrice = effectivePages * 1.5; // ₹1.5 per page
      } else {
        effectivePages = Math.ceil(pages / 2);
        basePrice = effectivePages * 1.7; // ₹1.7 per sheet
      }
    } else {
      if (sideType === 'Single Side') {
        basePrice = effectivePages * 8; // ₹8 per page
      } else {
        effectivePages = Math.ceil(pages / 2);
        basePrice = effectivePages * 12; // ₹12 per sheet
      }
    }

    // Add binding cost
    if (service === 'Spiral Binding') {
      if (effectivePages <= 60) basePrice += 25;
      else if (effectivePages <= 100) basePrice += 30;
      else if (effectivePages <= 120) basePrice += 35;
      else basePrice += 40;
    } else if (service === 'Soft Binding') {
      basePrice += 25;
    }

    return Math.round(basePrice * copies);
  };

  const totalPrice = calculatePrice();

  // Handle file upload success
  const handleUploadSuccess = (fileInfo: any) => {
    setUploadedFileUrl(fileInfo.cdnUrl);
    setFileName(fileInfo.name);
    
    // Try to detect pages from file name or use default
    const pageMatch = fileInfo.name.match(/(\d+)[\s_-]?pages?/i);
    if (pageMatch) {
      setPages(parseInt(pageMatch[1]));
    }
  };

  // Handle form submission
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!name.trim() || !phone.trim() || !uploadedFileUrl) {
      alert('Please fill in all required fields and upload a file.');
      return;
    }

    setIsSubmitting(true);

    try {
      // Save to Firebase Firestore (collection: orders)
      await addOrder({
        name: name.trim(),
        phone: phone.trim(),
        service,
        side_type: sideType,
        color_type: colorType,
        copies,
        pages,
        total_price: totalPrice,
        file_url: uploadedFileUrl, // Use uploadedFileUrl from Uploadcare
        timestamp: new Date()
      });

      // Show success message
      setShowSuccess(true);
      
      // Reset form after 3 seconds
      setTimeout(() => {
        setShowSuccess(false);
        setName('');
        setPhone('');
        setService('Printing');
        setSideType('Single Side');
        setColorType('Black & White');
        setCopies(1);
        setPages(1);
        setUploadedFileUrl('');
        setFileName('');
      }, 3000);

    } catch (error) {
      console.error('Error submitting order:', error);
      alert('Error submitting order. Please try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100 py-12">
      <div className="max-w-2xl mx-auto px-4 sm:px-6 lg:px-8">
        {/* Success Popup */}
        {showSuccess && (
          <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50">
            <div className="bg-white rounded-2xl shadow-2xl p-8 max-w-md mx-4 text-center animate-fade-in">
              <div className="w-16 h-16 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <CheckCircle className="w-8 h-8 text-green-600" />
              </div>
              <h3 className="text-2xl font-bold text-gray-900 mb-2">Order Placed Successfully! 🎉</h3>
              <p className="text-gray-600 mb-4">
                Your order is placed! Aishwarya Xerox will contact you soon.
              </p>
              <div className="bg-blue-50 rounded-lg p-4">
                <p className="text-blue-800 font-medium">Order Total: ₹{totalPrice}</p>
                <p className="text-blue-600 text-sm">We'll call you within 10 minutes!</p>
              </div>
            </div>
          </div>
        )}

        {/* Main Form */}
        <div className="bg-white rounded-2xl shadow-xl overflow-hidden">
          {/* Header */}
          <div className="bg-gradient-to-r from-blue-600 to-blue-700 text-white px-8 py-6">
            <h1 className="text-3xl font-bold mb-2">Place Your Order</h1>
            <p className="text-blue-100">Fast, reliable printing and binding services</p>
          </div>

          <form onSubmit={handleSubmit} className="p-8 space-y-6">
            {/* Customer Information */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Full Name <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <User className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="text"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter your full name"
                    required
                  />
                </div>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Phone Number <span className="text-red-500">*</span>
                </label>
                <div className="relative">
                  <Phone className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-gray-400" />
                  <input
                    type="tel"
                    value={phone}
                    onChange={(e) => setPhone(e.target.value)}
                    className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    placeholder="Enter your phone number"
                    required
                  />
                </div>
              </div>
            </div>

            {/* Service Options */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Service Type</label>
                <select
                  value={service}
                  onChange={(e) => setService(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="Printing">Printing</option>
                  <option value="Spiral Binding">Spiral Binding</option>
                  <option value="Soft Binding">Soft Binding</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Side Type</label>
                <select
                  value={sideType}
                  onChange={(e) => setSideType(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="Single Side">Single Side</option>
                  <option value="Double Side">Double Side</option>
                </select>
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Color Type</label>
                <select
                  value={colorType}
                  onChange={(e) => setColorType(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="Black & White">Black & White</option>
                  <option value="Color">Color</option>
                </select>
              </div>
            </div>

            {/* Copies and Pages */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Number of Copies</label>
                <input
                  type="number"
                  min="1"
                  max="100"
                  value={copies}
                  onChange={(e) => setCopies(parseInt(e.target.value) || 1)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-2">Number of Pages</label>
                <input
                  type="number"
                  min="1"
                  max="1000"
                  value={pages}
                  onChange={(e) => setPages(parseInt(e.target.value) || 1)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                />
              </div>
            </div>

            {/* File Upload with Uploadcare */}
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Upload File <span className="text-red-500">*</span>
              </label>
              
              {!uploadedFileUrl ? (
                <div className="border-2 border-dashed border-gray-300 rounded-lg p-6 text-center">
                  <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
                  <div
                    dangerouslySetInnerHTML={{
                      __html: `
                        <lr-file-uploader-regular
                          ctx-name="my-uploader"
                          css-src="https://cdn.jsdelivr.net/npm/@uploadcare/blocks@0.35.2/web/lr-file-uploader-regular.min.css"
                          class="uploadcare-config"
                          pubkey="1f8324d891ede1ba325a"
                          max-local-file-size-bytes="10000000"
                          multiple="false"
                          img-only="false"
                          source-list="local,url,camera,dropbox,gdrive"
                        ></lr-file-uploader-regular>
                        <script>
                          window.addEventListener('LR_UPLOAD_FINISH', (e) => {
                            const fileInfo = e.detail;
                            window.handleUploadSuccess && window.handleUploadSuccess(fileInfo);
                          });
                        </script>
                      `
                    }}
                  />
                </div>
              ) : (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center space-x-3">
                    <div className="w-10 h-10 bg-green-100 rounded-full flex items-center justify-center">
                      <FileText className="w-5 h-5 text-green-600" />
                    </div>
                    <div className="flex-1">
                      <p className="font-medium text-green-900">✅ File Uploaded Successfully</p>
                      <p className="text-sm text-green-700">{fileName}</p>
                      <a 
                        href={uploadedFileUrl} 
                        target="_blank" 
                        rel="noopener noreferrer"
                        className="text-blue-600 hover:text-blue-800 text-sm underline"
                      >
                        📄 View File
                      </a>
                    </div>
                    <button
                      type="button"
                      onClick={() => {
                        setUploadedFileUrl('');
                        setFileName('');
                      }}
                      className="text-red-600 hover:text-red-800 text-sm"
                    >
                      Remove
                    </button>
                  </div>
                </div>
              )}
            </div>

            {/* Price Calculation */}
            <div className="bg-blue-50 rounded-lg p-6 border border-blue-200">
              <h3 className="text-lg font-semibold text-blue-900 mb-4 flex items-center">
                <Calculator className="w-5 h-5 mr-2" />
                Price Calculation
              </h3>
              <div className="space-y-2 text-blue-800">
                <div className="flex justify-between">
                  <span>Service:</span>
                  <span className="font-semibold">{service}</span>
                </div>
                <div className="flex justify-between">
                  <span>Pages:</span>
                  <span className="font-semibold">{pages}</span>
                </div>
                <div className="flex justify-between">
                  <span>Type:</span>
                  <span className="font-semibold">{colorType} • {sideType}</span>
                </div>
                <div className="flex justify-between">
                  <span>Copies:</span>
                  <span className="font-semibold">{copies}</span>
                </div>
                <div className="border-t border-blue-200 pt-2 mt-2">
                  <div className="flex justify-between font-bold text-xl">
                    <span>Total:</span>
                    <span>₹{totalPrice}</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Submit Button */}
            <button
              type="submit"
              disabled={isSubmitting || !uploadedFileUrl}
              className={`
                w-full py-4 px-6 rounded-lg font-semibold text-lg transition-all duration-300 
                flex items-center justify-center space-x-2 shadow-lg
                ${isSubmitting || !uploadedFileUrl
                  ? 'bg-gray-400 text-gray-600 cursor-not-allowed'
                  : 'bg-gradient-to-r from-green-600 to-green-700 text-white hover:from-green-700 hover:to-green-800 transform hover:scale-105 hover:shadow-xl animate-pulse hover:animate-none'
                }
              `}
            >
              <ShoppingCart className="w-5 h-5" />
              <span>
                {isSubmitting ? 'Placing Order...' : `Order Now - ₹${totalPrice}`}
              </span>
            </button>

            <p className="text-sm text-gray-600 text-center">
              <strong>Note:</strong> After placing your order, we'll call you within 10 minutes to confirm details.
            </p>
          </form>
        </div>
      </div>

      {/* Add global handler for Uploadcare */}
      <script
        dangerouslySetInnerHTML={{
          __html: `
            window.handleUploadSuccess = function(fileInfo) {
              const event = new CustomEvent('uploadcare-success', { detail: fileInfo });
              window.dispatchEvent(event);
            };
          `
        }}
      />
    </div>
  );
};

// Add event listener for Uploadcare success
if (typeof window !== 'undefined') {
  window.addEventListener('uploadcare-success', (e: any) => {
    const fileInfo = e.detail;
    // This will be handled by the component's useEffect
  });
}

export default OrderForm;