import React from 'react';
import { Award, Users, Clock, Star, Target, Heart, Zap, Shield, Phone, Mail, MapPin, Printer, BookOpen, FileText, Palette } from 'lucide-react';

const About: React.FC = () => {
  const stats = [
    {
      icon: '😀',
      title: '1000+',
      text: 'Happy Customers'
    },
    {
      icon: '📄',
      title: '50,000+',
      text: 'Documents Printed'
    },
    {
      icon: '🎓',
      title: '5+',
      text: 'Years of Experience'
    },
    {
      icon: '⏱️',
      title: '< 24hrs',
      text: 'Average Turnaround'
    }
  ];

  const values = [
    {
      icon: '✅',
      title: 'Quality First',
      text: 'We never compromise on the quality of our printing and binding services.'
    },
    {
      icon: '⚡',
      title: 'Fast Service',
      text: 'Quick turnaround times without sacrificing attention to detail.'
    },
    {
      icon: '💙',
      title: 'Customer Care',
      text: 'Your satisfaction is our priority. We\'re here to help every step of the way.'
    }
  ];

  const services = [
    {
      icon: '🖨️',
      title: 'High-Quality Printing',
      text: 'Both B&W and color printing with premium quality paper'
    },
    {
      icon: '📚',
      title: 'Professional Binding',
      text: 'Spiral, soft, and thesis binding options available'
    },
    {
      icon: '⏱️',
      title: 'Quick Turnaround',
      text: 'Fast processing with same-day service available'
    },
    {
      icon: '📞',
      title: 'Personal Service',
      text: 'We call you within 10 minutes of order placement'
    }
  ];

  const contactInfo = [
    {
      icon: '📍',
      title: 'Visit Us',
      text: 'ADB road, near pragati engg college, surampalem, ramesampeta, 533437, AP'
    },
    {
      icon: '📞',
      title: 'Call Us',
      text: '+91 6301526803\nMon–Sat: 8:30 AM – 9:30 PM\nSun: 11:00 AM – 9:30 PM'
    },
    {
      icon: '📧',
      title: 'Email Us',
      text: 'aishwaryaxerox1999@gmail.com\nWe reply within 24 hours'
    }
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-50 to-gray-100">
      {/* Page Header */}
      <section className="bg-white py-16">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h1 className="text-4xl md:text-5xl font-bold text-gray-900 mb-6">
            About Aishwarya Xerox
          </h1>
          <p className="text-xl text-gray-600 max-w-3xl mx-auto leading-relaxed">
            Your trusted partner for professional printing and binding services. We combine 
            traditional quality with modern convenience to serve you better.
          </p>
        </div>
      </section>

      {/* Statistics Cards */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {stats.map((stat, index) => (
              <div 
                key={index} 
                className="bg-white rounded-2xl shadow-lg p-6 text-center transform hover:scale-105 transition-all duration-300"
              >
                <div className="text-4xl mb-3">{stat.icon}</div>
                <div className="text-3xl font-bold text-gray-900 mb-2">{stat.title}</div>
                <div className="text-gray-600 font-medium">{stat.text}</div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Our Story */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Story</h2>
              <div className="space-y-6 text-gray-600 text-lg leading-relaxed">
                <p>
                  Founded with a vision to provide high-quality, affordable printing services, 
                  Aishwarya Xerox has been serving the community for over 5 years. What started 
                  as a small neighborhood print shop has grown into a trusted name in professional 
                  document services.
                </p>
                <p>
                  We understand that every document tells a story – whether it's a student's thesis, 
                  a business proposal, or family memories. That's why we treat each project with the 
                  care and attention it deserves.
                </p>
                <p>
                  Today, we're proud to offer cutting-edge online ordering while maintaining the 
                  personal touch that our customers have come to expect.
                </p>
              </div>
            </div>
            
            <div className="space-y-6">
              <h2 className="text-3xl font-bold text-gray-900 mb-6">Our Values</h2>
              <div className="space-y-6">
                {values.map((value, index) => (
                  <div key={index} className="bg-gray-50 rounded-xl p-6 shadow-md">
                    <div className="flex items-start space-x-4">
                      <div className="text-2xl">{value.icon}</div>
                      <div>
                        <h3 className="text-xl font-semibold text-gray-900 mb-2">{value.title}</h3>
                        <p className="text-gray-600">{value.text}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* What We Offer */}
      <section className="py-20 bg-gray-50">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">What We Offer</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-8">
            {services.map((service, index) => (
              <div key={index} className="bg-white rounded-2xl shadow-lg p-6 text-center transform hover:scale-105 transition-all duration-300">
                <div className="text-4xl mb-4">{service.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-3">{service.title}</h3>
                <p className="text-gray-600">{service.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Get In Touch */}
      <section className="py-20 bg-white">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold text-gray-900 mb-4">Get In Touch</h2>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {contactInfo.map((contact, index) => (
              <div key={index} className="bg-gray-50 rounded-2xl shadow-lg p-8 text-center">
                <div className="text-4xl mb-4">{contact.icon}</div>
                <h3 className="text-xl font-semibold text-gray-900 mb-4">{contact.title}</h3>
                <p className="text-gray-600 whitespace-pre-line">{contact.text}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-900 text-white py-16">
        <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {/* Left Column */}
            <div>
              <h3 className="text-2xl font-bold mb-4">Aishwarya Xerox</h3>
              <p className="text-gray-300 leading-relaxed">
                Your trusted partner for all printing and binding needs. Fast, reliable, 
                and affordable services.
              </p>
            </div>
            
            {/* Center Column */}
            <div>
              <h3 className="text-xl font-bold mb-4">Contact Us</h3>
              <div className="space-y-3 text-gray-300">
                <p className="flex items-center space-x-2">
                  <Phone className="w-4 h-4" />
                  <span>+91 6301526803</span>
                </p>
                <p className="flex items-center space-x-2">
                  <Mail className="w-4 h-4" />
                  <span>aishwaryaxerox1999@gmail.com</span>
                </p>
                <p className="flex items-start space-x-2">
                  <MapPin className="w-4 h-4 mt-1 flex-shrink-0" />
                  <span>ADB road, near pragati engg college, surampalem, ramesampeta, 533437, AP</span>
                </p>
              </div>
            </div>
            
            {/* Right Column */}
            <div>
              <h3 className="text-xl font-bold mb-4">Quick Links</h3>
              <div className="space-y-2 text-gray-300">
                <p className="hover:text-white cursor-pointer transition-colors">Printing</p>
                <p className="hover:text-white cursor-pointer transition-colors">Custom Printing</p>
                <p className="hover:text-white cursor-pointer transition-colors">About Us</p>
                <p className="hover:text-white cursor-pointer transition-colors">Contact</p>
                <p className="hover:text-white cursor-pointer transition-colors">WhatsApp Support</p>
              </div>
            </div>
          </div>
          
          <div className="mt-12 pt-8 border-t border-gray-700 text-center text-gray-400">
            <p>&copy; 2024 Aishwarya Xerox. All rights reserved.</p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default About;