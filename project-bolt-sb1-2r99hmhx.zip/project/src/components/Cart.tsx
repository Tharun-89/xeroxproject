import React from 'react';
import { ShoppingCart, Trash2, FileText, Calendar, Package, ArrowRight } from 'lucide-react';
import { CartItem } from '../types';
import { addOrder, uploadFile } from '../lib/firebase';

interface CartProps {
  cartItems: CartItem[];
  onRemoveItem: (id: string) => void;
  onClearCart: () => void;
}

const Cart: React.FC<CartProps> = ({ cartItems, onRemoveItem, onClearCart }) => {
  const totalAmount = cartItems.reduce((sum, item) => sum + item.price, 0);

  const handlePlaceOrder = async () => {
    if (cartItems.length === 0) {
      alert('Your cart is empty!');
      return;
    }

    try {
      // Show loading message
      const loadingMessage = `Processing ${cartItems.length} order(s)...`;
      console.log(loadingMessage);

      // Create orders for each cart item
      const orderPromises = cartItems.map(async (item) => {
        let fileUrl = '';
        
        // Upload file to Firebase when order is placed (fast upload only when needed)
        if (item.options?.customerInfo?.file) {
          const file = item.options.customerInfo.file;
          const fileName = `orders/${Date.now()}_${file.name}`;
          console.log(`Uploading file: ${file.name}...`);
          fileUrl = await uploadFile(file, fileName);
          console.log(`File uploaded successfully: ${fileUrl}`);
        }

        // Create order data - Send to Firebase Firestore, collection = orders
        const orderData = {
          name: item.options?.customerInfo?.fullName || 'Unknown Customer',
          phone: item.options?.customerInfo?.phoneNumber || 'No Phone',
          service: item.serviceName,
          total_price: item.price,
          file_url: fileUrl, // Save field: file_url = {{uploadedFileUrl}}
          timestamp: item.timestamp
        };

        return addOrder(orderData);
      });

      await Promise.all(orderPromises);

      const orderSummary = cartItems.map(item => 
        `${item.serviceName} - ${item.fileName} - ₹${item.price}`
      ).join('\n');

      alert(`Order Placed Successfully!\n\nOrder Summary:\n${orderSummary}\n\nTotal: ₹${totalAmount}\n\nThank you for choosing Aishwarya Xerox!`);
      onClearCart();
    } catch (error) {
      console.error('Error placing order:', error);
      alert('Failed to place order. Please try again.');
    }
  };

  const handleBrowseServices = () => {
    // Scroll to services section on home page
    const servicesSection = document.getElementById('services');
    if (servicesSection) {
      servicesSection.scrollIntoView({ behavior: 'smooth' });
    } else {
      // If not on home page, navigate to home and then scroll
      window.location.href = '/#services';
    }
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getServiceColor = (serviceName: string) => {
    switch (serviceName) {
      case 'Printing':
        return 'bg-blue-100 text-blue-800';
      case 'Spiral Binding':
        return 'bg-green-100 text-green-800';
      case 'Soft Binding':
        return 'bg-purple-100 text-purple-800';
      case 'Custom Printing':
        return 'bg-orange-100 text-orange-800';
      case 'Color Custom Pages':
        return 'bg-pink-100 text-pink-800';
      default:
        return 'bg-gray-100 text-gray-800';
    }
  };

  return (
    <div className="min-h-screen bg-gray-50 py-12">
      <div className="max-w-6xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center mb-12">
          <h1 className="text-4xl font-bold text-gray-900 mb-4 flex items-center justify-center">
            <ShoppingCart className="w-10 h-10 mr-3 text-blue-600" />
            My Orders
          </h1>
          <p className="text-xl text-gray-600">Review your cart and place your order</p>
        </div>

        {cartItems.length === 0 ? (
          <div className="text-center py-16">
            <div className="bg-white rounded-2xl shadow-xl p-12 max-w-2xl mx-auto">
              <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                <ShoppingCart className="w-12 h-12 text-gray-400" />
              </div>
              <h2 className="text-3xl font-bold text-gray-900 mb-4">🛒 Your cart is empty!</h2>
              <p className="text-xl text-gray-600 mb-8">
                Add some items to your cart to get started with our printing services
              </p>
              
              <button
                onClick={handleBrowseServices}
                className="
                  bg-gradient-to-r from-blue-600 to-blue-700 text-white 
                  px-8 py-4 rounded-lg font-semibold text-lg 
                  hover:from-blue-700 hover:to-blue-800 
                  transition-all duration-300 transform hover:scale-105 
                  flex items-center space-x-3 mx-auto shadow-lg
                  animate-pulse hover:animate-none
                  hover:shadow-xl
                "
              >
                <span>Browse Services</span>
                <ArrowRight className="w-5 h-5" />
              </button>
              
              <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-blue-50 p-4 rounded-lg">
                  <div className="text-2xl mb-2">🖨️</div>
                  <p className="text-sm font-medium text-blue-900">Printing</p>
                </div>
                <div className="bg-green-50 p-4 rounded-lg">
                  <div className="text-2xl mb-2">📚</div>
                  <p className="text-sm font-medium text-green-900">Spiral Binding</p>
                </div>
                <div className="bg-purple-50 p-4 rounded-lg">
                  <div className="text-2xl mb-2">📄</div>
                  <p className="text-sm font-medium text-purple-900">Soft Binding</p>
                </div>
                <div className="bg-orange-50 p-4 rounded-lg">
                  <div className="text-2xl mb-2">🎨</div>
                  <p className="text-sm font-medium text-orange-900">Custom Print</p>
                </div>
              </div>
            </div>
          </div>
        ) : (
          <div className="space-y-6">
            {/* Cart Items */}
            <div className="bg-white rounded-2xl shadow-lg overflow-hidden">
              <div className="p-6 border-b border-gray-200">
                <div className="flex justify-between items-center">
                  <h2 className="text-2xl font-semibold text-gray-900">
                    Cart Items ({cartItems.length})
                  </h2>
                  <button
                    onClick={onClearCart}
                    className="text-red-600 hover:text-red-700 font-medium flex items-center space-x-1"
                  >
                    <Trash2 className="w-4 h-4" />
                    <span>Clear All</span>
                  </button>
                </div>
              </div>

              <div className="divide-y divide-gray-200">
                {cartItems.map((item) => (
                  <div key={item.id} className="p-6 hover:bg-gray-50 transition-colors">
                    <div className="flex items-start justify-between">
                      <div className="flex-1">
                        <div className="flex items-center space-x-3 mb-3">
                          <span className={`px-3 py-1 rounded-full text-sm font-medium ${getServiceColor(item.serviceName)}`}>
                            {item.serviceName}
                          </span>
                          <span className="text-sm text-gray-500 flex items-center">
                            <Calendar className="w-4 h-4 mr-1" />
                            {formatDate(item.timestamp)}
                          </span>
                        </div>

                        <div className="flex items-center space-x-2 mb-2">
                          <FileText className="w-5 h-5 text-gray-400" />
                          <span className="font-medium text-gray-900">{item.fileName}</span>
                          <span className="text-sm text-gray-500">
                            ({item.pageCount} pages)
                          </span>
                        </div>

                        {/* Show file ready status */}
                        <div className="mb-2">
                          <div className="inline-flex items-center space-x-1 text-green-600 bg-green-50 px-3 py-1 rounded-lg text-sm">
                            <FileText className="w-4 h-4" />
                            <span>📄 File Ready (will upload when order is placed)</span>
                          </div>
                        </div>

                        <div className="text-sm text-gray-600 space-y-1">
                          {item.serviceName === 'Printing' && (
                            <>
                              <p>Print Type: {item.options.printType?.replace('-', ' ').toUpperCase()}</p>
                              <p>Copies: {item.options.copies}</p>
                            </>
                          )}
                          {item.serviceName === 'Spiral Binding' && (
                            <>
                              <p>Double Side: {item.options.isDoubleSide ? 'Yes' : 'No'}</p>
                              <p>Copies: {item.options.copies}</p>
                            </>
                          )}
                          {item.serviceName === 'Soft Binding' && (
                            <>
                              <p>Print Type: {item.options.printType?.replace('-', ' ').toUpperCase()}</p>
                              <p>Copies: {item.options.copies}</p>
                            </>
                          )}
                          {item.serviceName === 'Custom Printing' && (
                            <>
                              <p>Layout: {item.options.customType}</p>
                              <p>Side: {item.options.isDoubleSide ? 'Double' : 'Single'}</p>
                              <p>Copies: {item.options.copies}</p>
                            </>
                          )}
                          {item.serviceName === 'Color Custom Pages' && (
                            <>
                              <p>Color Pages: {item.options.colorPages}</p>
                              <p>Print Type: {item.options.printType} side</p>
                              <p>Copies: {item.options.copies}</p>
                            </>
                          )}
                        </div>
                      </div>

                      <div className="flex items-center space-x-4">
                        <div className="text-right">
                          <p className="text-2xl font-bold text-gray-900">₹{item.price}</p>
                        </div>
                        <button
                          onClick={() => onRemoveItem(item.id)}
                          className="text-red-600 hover:text-red-700 p-2 rounded-lg hover:bg-red-50 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </div>

            {/* Order Summary */}
            <div className="bg-white rounded-2xl shadow-lg p-6">
              <h3 className="text-xl font-semibold text-gray-900 mb-4">Order Summary</h3>
              
              <div className="space-y-3">
                <div className="flex justify-between text-gray-600">
                  <span>Items ({cartItems.length})</span>
                  <span>₹{totalAmount}</span>
                </div>
                <div className="flex justify-between text-gray-600">
                  <span>Processing Fee</span>
                  <span>₹0</span>
                </div>
                <div className="border-t border-gray-200 pt-3">
                  <div className="flex justify-between text-xl font-bold text-gray-900">
                    <span>Total</span>
                    <span>₹{totalAmount}</span>
                  </div>
                </div>
              </div>

              <button
                onClick={handlePlaceOrder}
                className="w-full mt-6 bg-gradient-to-r from-green-600 to-green-700 text-white py-4 px-6 rounded-lg font-semibold text-lg hover:from-green-700 hover:to-green-800 transition-all duration-300 transform hover:scale-105"
              >
                Place Order - ₹{totalAmount}
              </button>

              <p className="text-sm text-gray-500 text-center mt-4">
                <strong>⚡ Fast Upload:</strong> Files will be uploaded to Firebase only when you place your order. This ensures quick form submission!
              </p>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default Cart;