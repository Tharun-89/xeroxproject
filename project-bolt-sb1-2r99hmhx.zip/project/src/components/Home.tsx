import React, { useState, useEffect } from 'react';
import { ArrowRight, Printer, BookOpen, FileText, Palette, Upload, Settings, ShoppingCart, Check, Clock, Shield, Camera, GraduationCap } from 'lucide-react';
import { PageType } from '../types';

interface HomeProps {
  onNavigate: (page: PageType) => void;
}

const Home: React.FC<HomeProps> = ({ onNavigate }) => {
  const [currentImageIndex, setCurrentImageIndex] = useState(0);
  
  const carouselImages = [
    'https://ucarecdn.com/194fbcb2-6f0a-43ee-9597-cf16f8d999ae/acolorfulmodernvectorillustrationsh_C7GMzBN9TnmvDVtmdlZ8Aw_K55q41xkQc23X9wTXZX7Ajpeg.jpg',
    'https://ucarecdn.com/08e0e09c-c5a2-4fa0-815b-dd2ad701c475/amodernvectorillustrationinaflats_cB6dpbwjSsuOn4lQ7kMQhQ_Tva0e9gyQVOXtBUSzrRgCgjpeg.jpg',
    'https://ucarecdn.com/10238789-60c2-4c5e-9bdf-461e324f6ccb/closeupviewofhandsbindingadocumen_EqMiPlmSdW15PoEEh96Q_ysro9U2_TZenxNBehSd_IQjpeg.jpg',
    'https://ucarecdn.com/cc605407-4781-4282-8e8d-098d6f65801b/inavibrantandmodernvectorstyleill_EXFwTzEBRPmStfugp7v22A_rqpPqbHzTeyIm9M0wSP2ig.jpeg'
  ];

  // Auto-advance carousel every 3 seconds
  useEffect(() => {
    const interval = setInterval(() => {
      setCurrentImageIndex((prevIndex) => 
        prevIndex === carouselImages.length - 1 ? 0 : prevIndex + 1
      );
    }, 3000);

    return () => clearInterval(interval);
  }, [carouselImages.length]);

  const services = [
    {
      name: 'Printing',
      icon: Printer,
      description: 'High-quality B&W and color printing',
      color: '#2563eb',
      lightColor: '#dbeafe',
      page: 'printing' as PageType,
      available: true
    },
    {
      name: 'Spiral Binding',
      icon: BookOpen,
      description: 'Professional spiral binding service',
      color: '#10b981',
      lightColor: '#d1fae5',
      page: 'spiral-binding' as PageType,
      available: true
    },
    {
      name: 'Soft Binding',
      icon: FileText,
      description: 'Elegant soft binding for documents',
      color: '#8b5cf6',
      lightColor: '#ede9fe',
      page: 'soft-binding' as PageType,
      available: true
    },
    {
      name: 'Custom Printing',
      icon: Palette,
      description: 'Special formats like 4-in-1, 8-in-1',
      color: '#f97316',
      lightColor: '#fed7aa',
      page: 'custom-printing' as PageType,
      available: true
    },
    {
      name: 'Thesis Binding',
      icon: GraduationCap,
      description: 'Coming Soon',
      color: '#d1d5db',
      lightColor: '#f3f4f6',
      page: 'services' as PageType,
      available: false
    },
    {
      name: 'Photo Frames',
      icon: Camera,
      description: 'Coming Soon',
      color: '#d1d5db',
      lightColor: '#f3f4f6',
      page: 'services' as PageType,
      available: false
    }
  ];

  const howItWorks = [
    {
      icon: Upload,
      title: 'Upload File',
      description: 'Upload your PDF or DOCX file easily'
    },
    {
      icon: Settings,
      title: 'Choose Service & Options',
      description: 'Select binding type, copies, and preferences'
    },
    {
      icon: ShoppingCart,
      title: 'Place Order',
      description: "Complete your order and we'll call you within 10 minutes"
    }
  ];

  const whyChooseUs = [
    {
      icon: Check,
      title: 'Quality Assured',
      description: 'Premium quality printing with attention to detail',
      color: 'blue'
    },
    {
      icon: Clock,
      title: 'Fast Turnaround',
      description: 'Quick processing and delivery times',
      color: 'green'
    },
    {
      icon: Shield,
      title: 'Secure & Reliable',
      description: 'Your documents are safe with us',
      color: 'mint'
    }
  ];

  const scrollToServices = () => {
    const servicesSection = document.getElementById('services');
    servicesSection?.scrollIntoView({ behavior: 'smooth' });
  };

  return (
    <div className="min-h-screen bg-white">
      {/* Hero Banner */}
      <section className="bg-gradient-to-r from-[#0A53C5] to-[#1C6DD0] text-white py-20">
        <div className="max-w-7xl mx-auto px-5">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-12 items-center">
            {/* Left Column - Text */}
            <div className="text-left">
              <h1 className="text-4xl lg:text-5xl xl:text-6xl font-bold mb-6 leading-tight">
                Fast, Reliable, and<br />
                Affordable Printing<br />
                Services
              </h1>
              <p className="text-lg lg:text-xl text-blue-100 mb-8 leading-relaxed max-w-lg">
                Get professional printing, binding, and document services with instant pricing and quick turnaround times.
              </p>
              <button
                onClick={scrollToServices}
                className="bg-white text-[#1A73E8] px-6 py-3 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 shadow-lg"
              >
                <span>Order Now</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
            
            {/* Right Column - Animated Image Carousel */}
            <div className="flex justify-center lg:justify-end">
              <div className="relative w-full max-w-md lg:max-w-lg">
                <div className="relative h-80 lg:h-96 rounded-2xl overflow-hidden shadow-2xl">
                  {carouselImages.map((image, index) => (
                    <div
                      key={index}
                      className={`absolute inset-0 transition-opacity duration-1000 ease-in-out ${
                        index === currentImageIndex ? 'opacity-100' : 'opacity-0'
                      }`}
                    >
                      <img
                        src={image}
                        alt={`Printing Service ${index + 1}`}
                        className="w-full h-full object-cover"
                      />
                    </div>
                  ))}
                  
                  {/* Carousel Indicators */}
                  <div className="absolute bottom-4 left-1/2 transform -translate-x-1/2 flex space-x-2">
                    {carouselImages.map((_, index) => (
                      <button
                        key={index}
                        onClick={() => setCurrentImageIndex(index)}
                        className={`w-3 h-3 rounded-full transition-all duration-300 ${
                          index === currentImageIndex 
                            ? 'bg-white scale-110' 
                            : 'bg-white/50 hover:bg-white/75'
                        }`}
                      />
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* Our Services Section */}
      <section id="services" className="py-15 bg-white">
        <div className="max-w-6xl mx-auto px-6">
          {/* Section Title */}
          <div className="text-center mb-8">
            <h2 className="text-3xl font-bold text-gray-900 mb-2">
              Our Services
            </h2>
            <p className="text-base text-gray-500">
              Professional printing and binding services tailored to your needs
            </p>
          </div>

          {/* Service Cards Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {services.map((service, index) => {
              const Icon = service.icon;
              
              return (
                <div
                  key={service.name}
                  className="bg-white rounded-2xl shadow-sm hover:shadow-lg transition-all duration-300 p-6 text-center flex flex-col"
                  style={{ 
                    width: '290px',
                    height: '260px',
                    margin: '0 auto',
                    boxShadow: '0 1px 3px 0 rgba(0, 0, 0, 0.05), 0 1px 2px 0 rgba(0, 0, 0, 0.05)',
                    animationDelay: `${index * 150}ms`
                  }}
                >
                  {/* Icon Section */}
                  <div className="flex justify-center mb-3">
                    <div 
                      className="w-12 h-12 rounded-full flex items-center justify-center"
                      style={{ backgroundColor: service.lightColor }}
                    >
                      <Icon 
                        className="w-6 h-6" 
                        style={{ color: service.color }}
                      />
                    </div>
                  </div>

                  {/* Title */}
                  <h3 className="text-base font-bold text-gray-900 mb-2">
                    {service.name}
                  </h3>

                  {/* Description */}
                  <p className="text-sm text-gray-500 leading-5 mb-4 flex-grow">
                    {service.description}
                  </p>

                  {/* Order Button */}
                  <button
                    onClick={() => service.available && onNavigate(service.page)}
                    disabled={!service.available}
                    className={`px-4 py-2 rounded-lg text-sm font-medium transition-all duration-200 flex items-center justify-center space-x-1 ${
                      service.available
                        ? 'text-white hover:opacity-90 transform hover:scale-105'
                        : 'bg-gray-200 text-gray-500 cursor-default'
                    }`}
                    style={{
                      backgroundColor: service.available ? service.color : '#e5e7eb',
                      color: service.available ? 'white' : '#6b7280'
                    }}
                  >
                    <span>Order Now</span>
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-16 bg-gray-50">
        <div className="max-w-7xl mx-auto px-5">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              How It Works
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Simple 3-step process to get your documents printed and bound
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {howItWorks.map((step, index) => {
              const Icon = step.icon;
              return (
                <div key={step.title} className="text-center">
                  <div className="w-20 h-20 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg">
                    <Icon className="w-10 h-10 text-blue-600" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{step.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{step.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-16 bg-white">
        <div className="max-w-7xl mx-auto px-5">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-gray-900 mb-4">
              Why Choose Us?
            </h2>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              We're committed to providing the best printing experience
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            {whyChooseUs.map((feature, index) => {
              const Icon = feature.icon;
              const colorClasses = {
                blue: 'text-blue-600 bg-blue-100',
                green: 'text-green-600 bg-green-100',
                mint: 'text-teal-600 bg-teal-100'
              };

              return (
                <div key={feature.title} className="text-center">
                  <div className={`w-16 h-16 rounded-full ${colorClasses[feature.color as keyof typeof colorClasses]} flex items-center justify-center mx-auto mb-6`}>
                    <Icon className="w-8 h-8" />
                  </div>
                  <h3 className="text-xl font-semibold text-gray-900 mb-3">{feature.title}</h3>
                  <p className="text-gray-600 leading-relaxed">{feature.description}</p>
                </div>
              );
            })}
          </div>
        </div>
      </section>

      {/* Call to Action */}
      <section className="py-16 bg-gradient-to-r from-[#0A53C5] to-[#1C6DD0]">
        <div className="max-w-7xl mx-auto px-5 text-center">
          <h2 className="text-3xl md:text-4xl font-bold text-white mb-4">
            Ready to Get Started?
          </h2>
          <p className="text-xl text-blue-100 mb-8 max-w-2xl mx-auto">
            Upload your documents and get instant pricing for all our services
          </p>
          <button
            onClick={scrollToServices}
            className="bg-white text-[#1A73E8] px-8 py-4 rounded-lg font-semibold text-lg hover:bg-blue-50 transition-all duration-300 transform hover:scale-105 flex items-center space-x-2 mx-auto shadow-lg"
          >
            <span>Start Your Order</span>
            <ArrowRight className="w-5 h-5" />
          </button>
        </div>
      </section>
    </div>
  );
};

export default Home;