import React, { useState, useCallback } from 'react';
import { Upload, FileText, Calculator, ShoppingCart, Palette } from 'lucide-react';
import { CartItem, FileUpload } from '../../types';
import { calculateColorCustomPrice, parseColorPageRange } from '../../utils/priceCalculations';
import { detectPageCount, isValidFileType, formatFileSize } from '../../utils/fileUtils';
import ServiceTabBar from '../ServiceTabBar';
import { PageType } from '../../types';

interface ColorCustomPagesProps {
  onAddToCart: (item: CartItem) => void;
  onNavigate?: (page: PageType) => void;
}

const ColorCustomPages: React.FC<ColorCustomPagesProps> = ({ onAddToCart, onNavigate }) => {
  const [uploadedFile, setUploadedFile] = useState<FileUpload | null>(null);
  const [colorPageInput, setColorPageInput] = useState('');
  const [printType, setPrintType] = useState('single');
  const [copies, setCopies] = useState(1);
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);

  const handleFileUpload = useCallback(async (file: File) => {
    if (!isValidFileType(file)) {
      alert('Please upload a valid file (.pdf, .docx, .txt)');
      return;
    }

    setUploading(true);
    try {
      const pageCount = await detectPageCount(file);
      setUploadedFile({
        file,
        pageCount,
        name: file.name,
      });
    } catch (error) {
      console.error('Error processing file:', error);
      alert('Error processing file. Please try again.');
    } finally {
      setUploading(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  }, [handleFileUpload]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
  }, []);

  const colorPages = parseColorPageRange(colorPageInput);
  const bwPages = uploadedFile ? uploadedFile.pageCount - colorPages : 0;
  
  const totalPrice = uploadedFile 
    ? calculateColorCustomPrice(uploadedFile.pageCount, colorPages, printType, copies)
    : 0;

  const handleAddToCart = () => {
    if (!uploadedFile) return;

    const cartItem: CartItem = {
      id: Date.now().toString(),
      serviceName: 'Color Custom Pages',
      fileName: uploadedFile.name,
      pageCount: uploadedFile.pageCount,
      options: {
        colorPageInput,
        colorPages,
        printType,
        copies,
      },
      price: totalPrice,
      timestamp: new Date(),
    };

    onAddToCart(cartItem);
    
    // Reset form
    setUploadedFile(null);
    setColorPageInput('');
    setPrintType('single');
    setCopies(1);
    
    alert('Item added to cart successfully!');
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Service Tab Bar */}
      {onNavigate && (
        <ServiceTabBar currentPage="color-custom" onNavigate={onNavigate} />
      )}
      
      <div className="py-12">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-4xl font-bold text-pink-900 mb-4">Color Custom Pages</h1>
            <p className="text-xl text-pink-700">Mix color and B&W printing for specific pages</p>
          </div>

          <div className="bg-white rounded-2xl shadow-xl p-8">
            {/* File Upload */}
            <div className="mb-8">
              <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                <Upload className="w-6 h-6 mr-2 text-pink-600" />
                Upload Document
              </h2>
              
              <div
                className={`border-2 border-dashed rounded-lg p-8 text-center transition-colors ${
                  dragActive
                    ? 'border-pink-500 bg-pink-50'
                    : 'border-gray-300 hover:border-pink-400'
                }`}
                onDrop={handleDrop}
                onDragOver={handleDragOver}
                onDragLeave={handleDragLeave}
              >
                {uploading ? (
                  <div className="animate-pulse">
                    <div className="w-16 h-16 bg-pink-100 rounded-full flex items-center justify-center mx-auto mb-4">
                      <Upload className="w-8 h-8 text-pink-600 animate-bounce" />
                    </div>
                    <p className="text-pink-600 font-medium">Processing file...</p>
                  </div>
                ) : uploadedFile ? (
                  <div className="text-pink-600">
                    <FileText className="w-16 h-16 mx-auto mb-4" />
                    <p className="font-medium">{uploadedFile.name}</p>
                    <p className="text-sm text-gray-600">
                      {formatFileSize(uploadedFile.file.size)} • {uploadedFile.pageCount} pages
                    </p>
                  </div>
                ) : (
                  <>
                    <Upload className="w-16 h-16 text-gray-400 mx-auto mb-4" />
                    <p className="text-gray-600 mb-2">
                      Drag and drop your file here, or click to browse
                    </p>
                    <p className="text-sm text-gray-500">
                      Supports PDF, DOCX, TXT files
                    </p>
                    <input
                      type="file"
                      accept=".pdf,.doc,.docx,.txt"
                      onChange={(e) => {
                        const file = e.target.files?.[0];
                        if (file) handleFileUpload(file);
                      }}
                      className="hidden"
                      id="file-upload"
                    />
                    <label
                      htmlFor="file-upload"
                      className="mt-4 inline-block bg-pink-600 text-white px-6 py-2 rounded-lg cursor-pointer hover:bg-pink-700 transition-colors"
                    >
                      Choose File
                    </label>
                  </>
                )}
              </div>
            </div>

            {/* Color Pages Input */}
            {uploadedFile && (
              <>
                <div className="mb-8">
                  <h2 className="text-2xl font-semibold text-gray-900 mb-4 flex items-center">
                    <Palette className="w-6 h-6 mr-2 text-pink-600" />
                    Specify Color Pages
                  </h2>
                  
                  <div className="space-y-4">
                    <div>
                      <label className="block text-sm font-medium text-gray-700 mb-2">
                        Color Page Numbers
                      </label>
                      <input
                        type="text"
                        placeholder="e.g., 1-5,8,10-12"
                        value={colorPageInput}
                        onChange={(e) => setColorPageInput(e.target.value)}
                        className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                      />
                      <p className="text-sm text-gray-600 mt-2">
                        Use comma to separate individual pages or ranges. Examples: "1,3,5" or "1-5,10-15"
                      </p>
                    </div>

                    {colorPageInput && (
                      <div className="bg-pink-50 rounded-lg p-4">
                        <h4 className="font-medium text-pink-900 mb-2">Page Breakdown:</h4>
                        <div className="grid grid-cols-2 gap-4 text-sm">
                          <div>
                            <span className="text-pink-700">Color Pages:</span>
                            <span className="font-semibold ml-2">{colorPages}</span>
                          </div>
                          <div>
                            <span className="text-gray-700">B&W Pages:</span>
                            <span className="font-semibold ml-2">{bwPages}</span>
                          </div>
                        </div>
                      </div>
                    )}
                  </div>
                </div>

                {/* Print Type */}
                <div className="mb-8">
                  <h3 className="text-lg font-semibold text-gray-900 mb-4">Print Type</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <label className={`block p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      printType === 'single' ? 'border-pink-500 bg-pink-50' : 'border-gray-200 hover:border-pink-300'
                    }`}>
                      <input
                        type="radio"
                        name="printType"
                        value="single"
                        checked={printType === 'single'}
                        onChange={(e) => setPrintType(e.target.value)}
                        className="sr-only"
                      />
                      <div className="text-center">
                        <span className="font-medium">Single Side</span>
                        <p className="text-sm text-gray-600 mt-1">Color: ₹8/page • B&W: ₹1.5/page</p>
                      </div>
                    </label>
                    
                    <label className={`block p-4 rounded-lg border-2 cursor-pointer transition-all ${
                      printType === 'double' ? 'border-pink-500 bg-pink-50' : 'border-gray-200 hover:border-pink-300'
                    }`}>
                      <input
                        type="radio"
                        name="printType"
                        value="double"
                        checked={printType === 'double'}
                        onChange={(e) => setPrintType(e.target.value)}
                        className="sr-only"
                      />
                      <div className="text-center">
                        <span className="font-medium">Double Side</span>
                        <p className="text-sm text-gray-600 mt-1">Color: ₹12/page • B&W: ₹1.7/page</p>
                      </div>
                    </label>
                  </div>
                </div>

                <div className="mb-8">
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Number of Copies
                  </label>
                  <input
                    type="number"
                    min="1"
                    max="100"
                    value={copies}
                    onChange={(e) => setCopies(parseInt(e.target.value) || 1)}
                    className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-pink-500 focus:border-transparent"
                  />
                </div>

                {/* Price Calculation */}
                {colorPageInput && (
                  <div className="bg-pink-50 rounded-lg p-6 mb-8">
                    <h3 className="text-lg font-semibold text-pink-900 mb-4 flex items-center">
                      <Calculator className="w-5 h-5 mr-2" />
                      Price Calculation
                    </h3>
                    <div className="space-y-2 text-pink-800">
                      <div className="flex justify-between">
                        <span>Total Pages:</span>
                        <span>{uploadedFile.pageCount}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Color Pages:</span>
                        <span>{colorPages}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>B&W Pages:</span>
                        <span>{bwPages}</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Print Type:</span>
                        <span className="capitalize">{printType} Side</span>
                      </div>
                      <div className="flex justify-between">
                        <span>Copies:</span>
                        <span>{copies}</span>
                      </div>
                      <div className="border-t border-pink-200 pt-2 mt-2">
                        <div className="flex justify-between font-bold text-lg">
                          <span>Total:</span>
                          <span>₹{totalPrice}</span>
                        </div>
                      </div>
                    </div>
                  </div>
                )}

                {/* Add to Cart Button */}
                <button
                  onClick={handleAddToCart}
                  disabled={!colorPageInput.trim()}
                  className="w-full bg-gradient-to-r from-pink-600 to-pink-700 text-white py-4 px-6 rounded-lg font-semibold text-lg hover:from-pink-700 hover:to-pink-800 transition-all duration-300 transform hover:scale-105 flex items-center justify-center space-x-2 disabled:opacity-50 disabled:cursor-not-allowed disabled:transform-none"
                >
                  <ShoppingCart className="w-5 h-5" />
                  <span>Add to Cart - ₹{totalPrice}</span>
                </button>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};

export default ColorCustomPages;