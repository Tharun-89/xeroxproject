import React, { useState, useCallback } from 'react';
import { Upload, FileText, Calculator, ShoppingCart, Phone, User, AlertTriangle, Palette } from 'lucide-react';
import { CartItem, FileUpload } from '../../types';
import { detectPageCount, isValidFileType, formatFileSize } from '../../utils/fileUtils';
import { 
  calculateCustomColorPrintingPrice, 
  parseColorPageRange, 
  validatePageRange 
} from '../../utils/priceCalculations';
import ServiceTabBar from '../ServiceTabBar';
import { PageType } from '../../types';

interface SoftBindingProps {
  onAddToCart: (item: CartItem) => void;
  onNavigate?: (page: PageType) => void;
}

const SoftBinding: React.FC<SoftBindingProps> = ({ onAddToCart, onNavigate }) => {
  const [uploadedFile, setUploadedFile] = useState<FileUpload | null>(null);
  const [printType, setPrintType] = useState('bw');
  const [sideType, setSideType] = useState('single');
  const [copies, setCopies] = useState(1);
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [pageDetectionWarning, setPageDetectionWarning] = useState(false);
  
  // Custom Color Page Selection
  const [colorPageInput, setColorPageInput] = useState('');
  const [pageRangeError, setPageRangeError] = useState('');

  const handleFileUpload = useCallback(async (file: File) => {
    if (!isValidFileType(file)) {
      alert('⚠️ Only regular PDF and DOCX files supported for accurate page detection');
      return;
    }

    setUploading(true);
    setPageDetectionWarning(false);
    
    try {
      const pageCount = await detectPageCount(file);
      
      setUploadedFile({
        file,
        pageCount,
        name: file.name,
      });

      // Clear color page input when new file is uploaded
      setColorPageInput('');
      setPageRangeError('');

      // Show warning if page count might be inaccurate
      if (pageCount === 1 && file.size > 100000) {
        setPageDetectionWarning(true);
      }
      
    } catch (error) {
      console.error('Error processing file:', error);
      setPageDetectionWarning(true);
      setUploadedFile({
        file,
        pageCount: 1,
        name: file.name,
      });
    } finally {
      setUploading(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  }, [handleFileUpload]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
  }, []);

  const handleColorPageInputChange = (value: string) => {
    setColorPageInput(value);
    
    if (uploadedFile && value.trim()) {
      const validation = validatePageRange(value, uploadedFile.pageCount);
      if (!validation.isValid) {
        setPageRangeError(validation.error || '');
      } else {
        setPageRangeError('');
      }
    } else {
      setPageRangeError('');
    }
  };

  const calculatePrice = () => {
    if (!uploadedFile) return 0;
    
    if (printType === 'custom' && colorPageInput.trim()) {
      // Custom color page pricing + soft binding
      const printPrice = calculateCustomColorPrintingPrice(
        uploadedFile.pageCount,
        colorPageInput,
        sideType,
        copies
      );
      const bindingCharge = 25 * copies; // ₹25 per copy
      return printPrice + bindingCharge;
    } else {
      // Regular pricing + soft binding
      let pricePerPage = 0;
      let effectivePages = uploadedFile.pageCount;

      if (printType === 'bw') {
        if (sideType === 'single') {
          pricePerPage = 1.5; // ₹1.5 per page
        } else {
          pricePerPage = 1.7; // ₹1.7 per sheet
          effectivePages = Math.ceil(uploadedFile.pageCount / 2);
        }
      } else if (printType === 'color') {
        if (sideType === 'single') {
          pricePerPage = 8; // ₹8 per page
        } else {
          pricePerPage = 12; // ₹12 per sheet
          effectivePages = Math.ceil(uploadedFile.pageCount / 2);
        }
      }

      const printPrice = effectivePages * pricePerPage * copies;
      const bindingCharge = 25 * copies; // ₹25 per copy
      return printPrice + bindingCharge;
    }
  };

  const totalPrice = calculatePrice();

  const handleAddToCart = () => {
    if (!uploadedFile || !fullName.trim() || !phoneNumber.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    if (printType === 'custom' && !colorPageInput.trim()) {
      alert('Please specify which pages should be printed in color');
      return;
    }

    if (printType === 'custom' && pageRangeError) {
      alert('Please fix the page range error before adding to cart');
      return;
    }

    const cartItem: CartItem = {
      id: Date.now().toString(),
      serviceName: 'Soft Binding',
      fileName: uploadedFile.name,
      pageCount: uploadedFile.pageCount,
      options: {
        printType: printType === 'custom' ? 'custom-color' : `${printType}-${sideType}`,
        sideType,
        copies,
        colorPageInput: printType === 'custom' ? colorPageInput : undefined,
        customerInfo: {
          fullName,
          phoneNumber
        }
      },
      price: totalPrice,
      timestamp: new Date(),
    };

    onAddToCart(cartItem);
    alert('Item added to cart successfully!');
  };

  const handleOrderNow = () => {
    if (!isFormComplete) {
      alert('Please fill in all required fields');
      return;
    }

    // Add to cart first
    const cartItem: CartItem = {
      id: Date.now().toString(),
      serviceName: 'Soft Binding',
      fileName: uploadedFile!.name,
      pageCount: uploadedFile!.pageCount,
      options: {
        printType: printType === 'custom' ? 'custom-color' : `${printType}-${sideType}`,
        sideType,
        copies,
        colorPageInput: printType === 'custom' ? colorPageInput : undefined,
        customerInfo: {
          fullName,
          phoneNumber
        }
      },
      price: totalPrice,
      timestamp: new Date(),
    };

    onAddToCart(cartItem);
    
    // Navigate to cart
    if (onNavigate) {
      onNavigate('cart');
    }
  };

  const isFormComplete = uploadedFile && fullName.trim() && phoneNumber.trim() && 
    (printType !== 'custom' || (colorPageInput.trim() && !pageRangeError));

  const getColorPageBreakdown = () => {
    if (!uploadedFile || printType !== 'custom' || !colorPageInput.trim()) return null;
    
    const colorPages = parseColorPageRange(colorPageInput);
    const bwPages = uploadedFile.pageCount - colorPages;
    
    return { colorPages, bwPages };
  };

  const colorBreakdown = getColorPageBreakdown();

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Service Tab Bar */}
      {onNavigate && (
        <ServiceTabBar currentPage="soft-binding" onNavigate={onNavigate} />
      )}
      
      <div className="py-6">
        <div className="w-full max-w-[650px] mx-auto px-4">
          {/* Compact Card Container */}
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            
            {/* Blue Theme Header - Compact */}
            <div className="bg-blue-600 text-white px-5 py-4">
              <h1 className="text-xl font-bold">Soft Binding Service</h1>
              <p className="text-blue-100 text-sm mt-1">Upload your document and get instant pricing</p>
            </div>

            <div className="p-5 space-y-5">
              {/* 1. File Upload - Compact */}
              <div>
                <h2 className="text-base font-semibold text-gray-900 mb-2">1. Upload Your Document</h2>
                
                <div
                  className={`border-2 border-dashed rounded-lg p-4 text-center transition-all duration-300 cursor-pointer h-[140px] flex flex-col justify-center ${
                    dragActive
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:border-blue-400 hover:bg-gray-50'
                  }`}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onClick={() => document.getElementById('file-upload')?.click()}
                >
                  {uploading ? (
                    <div className="animate-pulse">
                      <Upload className="w-8 h-8 text-blue-600 mx-auto mb-2 animate-bounce" />
                      <p className="text-blue-600 font-medium text-sm">Processing file...</p>
                    </div>
                  ) : uploadedFile ? (
                    <div className="text-blue-600">
                      <FileText className="w-8 h-8 mx-auto mb-2" />
                      <p className="font-medium text-gray-900 text-sm">
                        Uploaded file: {uploadedFile.name} ({uploadedFile.pageCount} pages)
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {formatFileSize(uploadedFile.file.size)}
                      </p>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-700 font-medium text-sm mb-1">
                        Click to upload PDF or DOCX
                      </p>
                      <p className="text-xs text-gray-500">
                        Supports drag & drop • .pdf, .docx only
                      </p>
                    </>
                  )}
                  
                  <input
                    type="file"
                    id="file-upload"
                    accept=".pdf,.docx"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file);
                    }}
                    className="hidden"
                  />
                </div>

                {/* Page Detection Warning - Compact */}
                {pageDetectionWarning && (
                  <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded-lg flex items-start space-x-2">
                    <AlertTriangle className="w-3 h-3 text-yellow-600 mt-0.5 flex-shrink-0" />
                    <p className="text-yellow-800 text-xs">
                      ⚠️ Only regular PDF and DOCX files supported for accurate page detection
                    </p>
                  </div>
                )}
              </div>

              {/* 2. Options Section - Compact */}
              <div>
                <h2 className="text-base font-semibold text-gray-900 mb-2">2. Choose Options</h2>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Print Type */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Print Type</label>
                    <select
                      value={printType}
                      onChange={(e) => setPrintType(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="bw">Black & White</option>
                      <option value="color">Color</option>
                      <option value="custom">Custom</option>
                    </select>
                  </div>

                  {/* Side Type */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Side Type</label>
                    <select
                      value={sideType}
                      onChange={(e) => setSideType(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="single">Single Side</option>
                      <option value="double">Double Side</option>
                    </select>
                  </div>

                  {/* Copies */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Copies</label>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={copies}
                      onChange={(e) => setCopies(parseInt(e.target.value) || 1)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>

                {/* Custom Color Page Selection */}
                {printType === 'custom' && uploadedFile && (
                  <div className="mt-3 p-3 bg-orange-50 border border-orange-200 rounded-lg">
                    <div className="flex items-center space-x-2 mb-2">
                      <Palette className="w-4 h-4 text-orange-600" />
                      <h3 className="text-sm font-semibold text-orange-900">Custom Color Page Selection</h3>
                    </div>
                    
                    <div className="space-y-2">
                      <input
                        type="text"
                        value={colorPageInput}
                        onChange={(e) => handleColorPageInputChange(e.target.value)}
                        placeholder="Enter color pages (e.g. 1-5,6,9,25-30)"
                        className={`w-full px-3 py-2 text-sm border rounded-lg focus:ring-2 focus:ring-orange-500 focus:border-transparent ${
                          pageRangeError ? 'border-red-300 bg-red-50' : 'border-gray-300'
                        }`}
                      />
                      
                      <p className="text-xs text-orange-700">
                        Pages entered here will be printed in color. Use comma to separate individual pages or ranges.
                      </p>
                      
                      {pageRangeError && (
                        <p className="text-xs text-red-600 flex items-center space-x-1">
                          <AlertTriangle className="w-3 h-3" />
                          <span>{pageRangeError}</span>
                        </p>
                      )}
                      
                      {colorBreakdown && !pageRangeError && (
                        <div className="bg-white rounded-lg p-2 border border-orange-200">
                          <div className="grid grid-cols-2 gap-2 text-xs">
                            <div>
                              <span className="text-orange-700">Color Pages:</span>
                              <span className="font-semibold ml-1">{colorBreakdown.colorPages}</span>
                            </div>
                            <div>
                              <span className="text-gray-700">B&W Pages:</span>
                              <span className="font-semibold ml-1">{colorBreakdown.bwPages}</span>
                            </div>
                          </div>
                        </div>
                      )}
                    </div>
                  </div>
                )}
              </div>

              {/* 3. User Information - Compact */}
              <div>
                <h2 className="text-base font-semibold text-gray-900 mb-2">3. Your Information</h2>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="absolute left-2 top-1/2 transform -translate-y-1/2 w-3 h-3 text-gray-400" />
                      <input
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full pl-7 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Enter your full name"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-2 top-1/2 transform -translate-y-1/2 w-3 h-3 text-gray-400" />
                      <input
                        type="tel"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="w-full pl-7 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Enter your phone number"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Live Price Calculation - Compact */}
              {uploadedFile && (
                <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
                  <h3 className="text-base font-semibold text-blue-900 mb-2 flex items-center">
                    <Calculator className="w-4 h-4 mr-1" />
                    Price Calculation
                  </h3>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Total Pages:</span>
                      <span className="font-semibold">{uploadedFile.pageCount}</span>
                    </div>
                    
                    {printType === 'custom' && colorBreakdown ? (
                      <>
                        <div className="flex justify-between">
                          <span className="text-gray-700">Color Pages:</span>
                          <span className="font-semibold">{colorBreakdown.colorPages}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-700">B&W Pages:</span>
                          <span className="font-semibold">{colorBreakdown.bwPages}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-700">Side Type:</span>
                          <span className="font-semibold capitalize">{sideType}</span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-700">Color Rate:</span>
                          <span className="font-semibold">
                            ₹{sideType === 'single' ? '8' : '12'} per {sideType === 'double' ? 'sheet' : 'page'}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-700">B&W Rate:</span>
                          <span className="font-semibold">
                            ₹{sideType === 'single' ? '1.5' : '1.7'} per {sideType === 'double' ? 'sheet' : 'page'}
                          </span>
                        </div>
                      </>
                    ) : (
                      <>
                        <div className="flex justify-between">
                          <span className="text-gray-700">Type:</span>
                          <span className="font-semibold">
                            {printType === 'bw' ? 'B&W' : 'Color'} ({sideType} side)
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-700">
                            {sideType === 'double' ? 'Sheets:' : 'Pages:'}
                          </span>
                          <span className="font-semibold">
                            {sideType === 'double' ? Math.ceil(uploadedFile.pageCount / 2) : uploadedFile.pageCount}
                          </span>
                        </div>
                        <div className="flex justify-between">
                          <span className="text-gray-700">Print Rate:</span>
                          <span className="font-semibold">
                            ₹{printType === 'bw' ? (sideType === 'single' ? '1.5' : '1.7') : 
                               (sideType === 'single' ? '8' : '12')} per {sideType === 'double' ? 'sheet' : 'page'}
                          </span>
                        </div>
                      </>
                    )}
                    
                    <div className="flex justify-between">
                      <span className="text-gray-700">Copies:</span>
                      <span className="font-semibold">{copies}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Binding Charge:</span>
                      <span className="font-semibold">₹{25 * copies}</span>
                    </div>
                    <div className="border-t border-blue-200 pt-1 mt-2">
                      <div className="flex justify-between font-bold text-lg text-blue-900">
                        <span>Total:</span>
                        <span>₹{totalPrice}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Action Buttons - Compact */}
              <div className="space-y-2">
                <button
                  onClick={handleAddToCart}
                  disabled={!isFormComplete}
                  className={`w-full h-10 px-4 rounded-lg font-semibold text-sm transition-all duration-300 flex items-center justify-center space-x-2 shadow-sm ${
                    isFormComplete
                      ? 'bg-blue-600 text-white hover:bg-blue-700 transform hover:scale-105'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Add to Cart – ₹{totalPrice}</span>
                </button>

                <button
                  onClick={handleOrderNow}
                  disabled={!isFormComplete}
                  className={`w-full h-10 px-4 rounded-lg font-semibold text-sm transition-all duration-300 shadow-sm ${
                    isFormComplete
                      ? 'bg-green-600 text-white hover:bg-green-700 transform hover:scale-105 hover:shadow-lg'
                      : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  Order Now – ₹{totalPrice}
                </button>
              </div>

              {/* Info Note - Compact */}
              <div className="p-2 bg-gray-50 rounded-lg">
                <p className="text-xs text-gray-600 text-center">
                  <strong>Note:</strong> After clicking "Order Now", we'll call you within 10 minutes to confirm your order.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SoftBinding;