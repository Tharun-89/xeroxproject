import React, { useState, useCallback } from 'react';
import { Upload, FileText, Calculator, ShoppingCart, Phone, User, AlertTriangle } from 'lucide-react';
import { CartItem, FileUpload } from '../../types';
import { detectPageCount, isValidFileType, formatFileSize } from '../../utils/fileUtils';
import ServiceTabBar from '../ServiceTabBar';
import { PageType } from '../../types';

interface CustomPrintingProps {
  onAddToCart: (item: CartItem) => void;
  onNavigate?: (page: PageType) => void;
}

const CustomPrinting: React.FC<CustomPrintingProps> = ({ onAddToCart, onNavigate }) => {
  const [uploadedFile, setUploadedFile] = useState<FileUpload | null>(null);
  const [customType, setCustomType] = useState('4-in-1');
  const [sideType, setSideType] = useState('double');
  const [copies, setCopies] = useState(1);
  const [fullName, setFullName] = useState('');
  const [phoneNumber, setPhoneNumber] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [pageDetectionWarning, setPageDetectionWarning] = useState(false);

  const handleFileUpload = useCallback(async (file: File) => {
    if (!isValidFileType(file)) {
      alert('⚠️ Only regular PDF and DOCX files supported for accurate page detection');
      return;
    }

    setUploading(true);
    setPageDetectionWarning(false);
    
    try {
      const pageCount = await detectPageCount(file);
      
      setUploadedFile({
        file,
        pageCount,
        name: file.name,
      });

      // Show warning if page count might be inaccurate
      if (pageCount === 1 && file.size > 100000) {
        setPageDetectionWarning(true);
      }
      
    } catch (error) {
      console.error('Error processing file:', error);
      setPageDetectionWarning(true);
      setUploadedFile({
        file,
        pageCount: 1,
        name: file.name,
      });
    } finally {
      setUploading(false);
    }
  }, []);

  const handleDrop = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
    
    const files = Array.from(e.dataTransfer.files);
    if (files.length > 0) {
      handleFileUpload(files[0]);
    }
  }, [handleFileUpload]);

  const handleDragOver = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(true);
  }, []);

  const handleDragLeave = useCallback((e: React.DragEvent) => {
    e.preventDefault();
    setDragActive(false);
  }, []);

  // Custom Printing Price Calculation Logic
  const calculatePrice = () => {
    if (!uploadedFile) return 0;
    
    let sheetCount = 0;
    let pricePerSheet = 0;

    switch (customType) {
      case '4-in-1':
        // Always double side for 4-in-1
        sheetCount = Math.ceil(uploadedFile.pageCount / 4);
        pricePerSheet = 1.7;
        break;
      case '8-in-1':
        if (sideType === 'single') {
          sheetCount = Math.ceil(uploadedFile.pageCount / 8);
          pricePerSheet = 3;
        } else {
          sheetCount = Math.ceil(uploadedFile.pageCount / 16);
          pricePerSheet = 5;
        }
        break;
      case '9-in-1':
        if (sideType === 'single') {
          sheetCount = Math.ceil(uploadedFile.pageCount / 9);
          pricePerSheet = 3;
        } else {
          sheetCount = Math.ceil(uploadedFile.pageCount / 18);
          pricePerSheet = 5;
        }
        break;
      default:
        return 0;
    }

    return sheetCount * pricePerSheet * copies;
  };

  const totalPrice = calculatePrice();

  const handleAddToCart = () => {
    if (!uploadedFile || !fullName.trim() || !phoneNumber.trim()) {
      alert('Please fill in all required fields');
      return;
    }

    const cartItem: CartItem = {
      id: Date.now().toString(),
      serviceName: 'Custom Printing',
      fileName: uploadedFile.name,
      pageCount: uploadedFile.pageCount,
      options: {
        customType,
        sideType,
        copies,
        customerInfo: {
          fullName,
          phoneNumber
        }
      },
      price: totalPrice,
      timestamp: new Date(),
    };

    onAddToCart(cartItem);
    alert('Item added to cart successfully!');
  };

  const handleOrderNow = () => {
    if (!isFormComplete) {
      alert('Please fill in all required fields');
      return;
    }

    // Add to cart first
    const cartItem: CartItem = {
      id: Date.now().toString(),
      serviceName: 'Custom Printing',
      fileName: uploadedFile!.name,
      pageCount: uploadedFile!.pageCount,
      options: {
        customType,
        sideType,
        copies,
        customerInfo: {
          fullName,
          phoneNumber
        }
      },
      price: totalPrice,
      timestamp: new Date(),
    };

    onAddToCart(cartItem);
    
    // Navigate to cart
    if (onNavigate) {
      onNavigate('cart');
    }
  };

  // Force double-side for 4-in-1 and update when customType changes
  React.useEffect(() => {
    if (customType === '4-in-1') {
      setSideType('double');
    }
  }, [customType]);

  const isFormComplete = uploadedFile && fullName.trim() && phoneNumber.trim();

  const getEffectiveSheets = () => {
    if (!uploadedFile) return 0;
    
    switch (customType) {
      case '4-in-1':
        return Math.ceil(uploadedFile.pageCount / 4);
      case '8-in-1':
        return sideType === 'single' 
          ? Math.ceil(uploadedFile.pageCount / 8)
          : Math.ceil(uploadedFile.pageCount / 16);
      case '9-in-1':
        return sideType === 'single' 
          ? Math.ceil(uploadedFile.pageCount / 9)
          : Math.ceil(uploadedFile.pageCount / 18);
      default:
        return 0;
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Service Tab Bar */}
      {onNavigate && (
        <ServiceTabBar currentPage="custom-printing" onNavigate={onNavigate} />
      )}
      
      <div className="py-6">
        <div className="w-full max-w-[650px] mx-auto px-4">
          {/* Compact Card Container */}
          <div className="bg-white rounded-xl shadow-lg overflow-hidden">
            
            {/* Blue Theme Header - Compact */}
            <div className="bg-blue-600 text-white px-5 py-4">
              <h1 className="text-xl font-bold">Custom Printing</h1>
              <p className="text-blue-100 text-sm mt-1">Upload your document and get instant pricing</p>
            </div>

            <div className="p-5 space-y-5">
              {/* 1. File Upload - Compact */}
              <div>
                <h2 className="text-base font-semibold text-gray-900 mb-2">1. Upload Your Document</h2>
                
                <div
                  className={`border-2 border-dashed rounded-lg p-4 text-center transition-all duration-300 cursor-pointer h-[140px] flex flex-col justify-center ${
                    dragActive
                      ? 'border-blue-500 bg-blue-50'
                      : 'border-gray-300 hover:border-blue-400 hover:bg-gray-50'
                  }`}
                  onDrop={handleDrop}
                  onDragOver={handleDragOver}
                  onDragLeave={handleDragLeave}
                  onClick={() => document.getElementById('file-upload')?.click()}
                >
                  {uploading ? (
                    <div className="animate-pulse">
                      <Upload className="w-8 h-8 text-blue-600 mx-auto mb-2 animate-bounce" />
                      <p className="text-blue-600 font-medium text-sm">Processing file...</p>
                    </div>
                  ) : uploadedFile ? (
                    <div className="text-blue-600">
                      <FileText className="w-8 h-8 mx-auto mb-2" />
                      <p className="font-medium text-gray-900 text-sm">
                        Uploaded file: {uploadedFile.name} ({uploadedFile.pageCount} pages)
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {formatFileSize(uploadedFile.file.size)}
                      </p>
                    </div>
                  ) : (
                    <>
                      <Upload className="w-8 h-8 text-gray-400 mx-auto mb-2" />
                      <p className="text-gray-700 font-medium text-sm mb-1">
                        Click to upload PDF or DOCX
                      </p>
                      <p className="text-xs text-gray-500">
                        Supports drag & drop • .pdf, .docx only
                      </p>
                    </>
                  )}
                  
                  <input
                    type="file"
                    id="file-upload"
                    accept=".pdf,.docx"
                    onChange={(e) => {
                      const file = e.target.files?.[0];
                      if (file) handleFileUpload(file);
                    }}
                    className="hidden"
                  />
                </div>

                {/* Page Detection Warning - Compact */}
                {pageDetectionWarning && (
                  <div className="mt-2 p-2 bg-yellow-50 border border-yellow-200 rounded-lg flex items-start space-x-2">
                    <AlertTriangle className="w-3 h-3 text-yellow-600 mt-0.5 flex-shrink-0" />
                    <p className="text-yellow-800 text-xs">
                      ⚠️ Only regular PDF and DOCX files supported for accurate page detection
                    </p>
                  </div>
                )}
              </div>

              {/* 2. Options Section - Compact */}
              <div>
                <h2 className="text-base font-semibold text-gray-900 mb-2">2. Choose Options</h2>
                
                <div className="grid grid-cols-1 sm:grid-cols-3 gap-3">
                  {/* Print Type */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Print Type</label>
                    <select
                      value={customType}
                      onChange={(e) => setCustomType(e.target.value)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    >
                      <option value="4-in-1">4 in 1</option>
                      <option value="8-in-1">Micro 8 in 1</option>
                      <option value="9-in-1">Micro 9 in 1</option>
                    </select>
                  </div>

                  {/* Side Type */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Side Type</label>
                    <select
                      value={sideType}
                      onChange={(e) => setSideType(e.target.value)}
                      disabled={customType === '4-in-1'}
                      className={`w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent ${
                        customType === '4-in-1' ? 'bg-gray-100 cursor-not-allowed' : ''
                      }`}
                    >
                      <option value="single">Single Side</option>
                      <option value="double">Double Side</option>
                    </select>
                    {customType === '4-in-1' && (
                      <p className="text-xs text-gray-500 mt-1">4-in-1 is always double-sided</p>
                    )}
                  </div>

                  {/* Copies */}
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">Copies</label>
                    <input
                      type="number"
                      min="1"
                      max="100"
                      value={copies}
                      onChange={(e) => setCopies(parseInt(e.target.value) || 1)}
                      className="w-full px-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                    />
                  </div>
                </div>
              </div>

              {/* 3. User Information - Compact */}
              <div>
                <h2 className="text-base font-semibold text-gray-900 mb-2">3. Your Information</h2>
                
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Full Name <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <User className="absolute left-2 top-1/2 transform -translate-y-1/2 w-3 h-3 text-gray-400" />
                      <input
                        type="text"
                        value={fullName}
                        onChange={(e) => setFullName(e.target.value)}
                        className="w-full pl-7 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Enter your full name"
                        required
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-sm font-medium text-gray-700 mb-1">
                      Phone Number <span className="text-red-500">*</span>
                    </label>
                    <div className="relative">
                      <Phone className="absolute left-2 top-1/2 transform -translate-y-1/2 w-3 h-3 text-gray-400" />
                      <input
                        type="tel"
                        value={phoneNumber}
                        onChange={(e) => setPhoneNumber(e.target.value)}
                        className="w-full pl-7 pr-3 py-2 text-sm border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                        placeholder="Enter your phone number"
                        required
                      />
                    </div>
                  </div>
                </div>
              </div>

              {/* Live Price Calculation - Compact */}
              {uploadedFile && (
                <div className="bg-blue-50 rounded-lg p-3 border border-blue-200">
                  <h3 className="text-base font-semibold text-blue-900 mb-2 flex items-center">
                    <Calculator className="w-4 h-4 mr-1" />
                    Price Calculation
                  </h3>
                  <div className="space-y-1 text-sm">
                    <div className="flex justify-between">
                      <span className="text-gray-700">Total Pages:</span>
                      <span className="font-semibold">{uploadedFile.pageCount}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Layout Type:</span>
                      <span className="font-semibold">{customType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Side Type:</span>
                      <span className="font-semibold capitalize">{sideType}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Effective Sheets:</span>
                      <span className="font-semibold">{getEffectiveSheets()}</span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Rate per Sheet:</span>
                      <span className="font-semibold">
                        ₹{customType === '4-in-1' ? '1.7' : 
                           (customType === '8-in-1' || customType === '9-in-1') ? 
                           (sideType === 'single' ? '3' : '5') : '0'}
                      </span>
                    </div>
                    <div className="flex justify-between">
                      <span className="text-gray-700">Copies:</span>
                      <span className="font-semibold">{copies}</span>
                    </div>
                    <div className="border-t border-blue-200 pt-1 mt-2">
                      <div className="flex justify-between font-bold text-lg text-blue-900">
                        <span>Total:</span>
                        <span>₹{totalPrice}</span>
                      </div>
                    </div>
                  </div>
                </div>
              )}

              {/* Action Buttons - Compact */}
              <div className="space-y-2">
                <button
                  onClick={handleAddToCart}
                  disabled={!isFormComplete}
                  className={`w-full h-10 px-4 rounded-lg font-semibold text-sm transition-all duration-300 flex items-center justify-center space-x-2 shadow-sm ${
                    isFormComplete
                      ? 'bg-blue-600 text-white hover:bg-blue-700 transform hover:scale-105'
                      : 'bg-gray-300 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  <ShoppingCart className="w-4 h-4" />
                  <span>Add to Cart – ₹{totalPrice}</span>
                </button>

                <button
                  onClick={handleOrderNow}
                  disabled={!isFormComplete}
                  className={`w-full h-10 px-4 rounded-lg font-semibold text-sm transition-all duration-300 shadow-sm ${
                    isFormComplete
                      ? 'bg-green-600 text-white hover:bg-green-700 transform hover:scale-105 hover:shadow-lg'
                      : 'bg-gray-200 text-gray-500 cursor-not-allowed'
                  }`}
                >
                  Order Now – ₹{totalPrice}
                </button>
              </div>

              {/* Info Note - Compact */}
              <div className="p-2 bg-gray-50 rounded-lg">
                <p className="text-xs text-gray-600 text-center">
                  <strong>Note:</strong> After clicking "Order Now", we'll call you within 10 minutes to confirm your order.
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default CustomPrinting;