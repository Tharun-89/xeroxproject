import React, { useState } from 'react';
import { Printer, BookOpen, FileText, Palette, ArrowRight, Star, Camera, GraduationCap } from 'lucide-react';
import { PageType } from '../types';

// Import service components
import PrintingService from './services/PrintingService';
import SpiralBinding from './services/SpiralBinding';
import SoftBinding from './services/SoftBinding';
import CustomPrinting from './services/CustomPrinting';
import ColorCustomPages from './services/ColorCustomPages';

interface ServicesProps {
  onNavigate: (page: PageType) => void;
  onAddToCart?: (item: any) => void;
}

const Services: React.FC<ServicesProps> = ({ onNavigate, onAddToCart }) => {
  const [activeTab, setActiveTab] = useState('printing');

  const tabs = [
    {
      id: 'printing',
      name: 'Printing',
      icon: Printer,
      color: 'blue',
      available: true
    },
    {
      id: 'spiral',
      name: 'Spiral',
      icon: BookOpen,
      color: 'green',
      available: true
    },
    {
      id: 'soft',
      name: 'Soft',
      icon: FileText,
      color: 'purple',
      available: true
    },
    {
      id: 'custom',
      name: 'Custom',
      icon: Palette,
      color: 'orange',
      available: true
    },
    {
      id: 'thesis',
      name: 'Thesis',
      icon: GraduationCap,
      color: 'gray',
      available: false
    },
    {
      id: 'photo',
      name: 'Photo',
      icon: Camera,
      color: 'gray',
      available: false
    }
  ];

  const getTabColorClasses = (color: string, isActive: boolean) => {
    const colorMap = {
      blue: {
        active: 'bg-blue-600 text-white border-blue-600',
        inactive: 'text-blue-600 border-gray-200 hover:border-blue-300 hover:bg-blue-50'
      },
      green: {
        active: 'bg-green-600 text-white border-green-600',
        inactive: 'text-green-600 border-gray-200 hover:border-green-300 hover:bg-green-50'
      },
      purple: {
        active: 'bg-purple-600 text-white border-purple-600',
        inactive: 'text-purple-600 border-gray-200 hover:border-purple-300 hover:bg-purple-50'
      },
      orange: {
        active: 'bg-orange-600 text-white border-orange-600',
        inactive: 'text-orange-600 border-gray-200 hover:border-orange-300 hover:bg-orange-50'
      },
      gray: {
        active: 'bg-gray-400 text-white border-gray-400',
        inactive: 'text-gray-400 border-gray-200 cursor-not-allowed'
      }
    };

    return colorMap[color as keyof typeof colorMap]?.[isActive ? 'active' : 'inactive'] || '';
  };

  const renderTabContent = () => {
    if (!onAddToCart) return null;

    switch (activeTab) {
      case 'printing':
        return <PrintingService onAddToCart={onAddToCart} onNavigate={onNavigate} />;
      case 'spiral':
        return <SpiralBinding onAddToCart={onAddToCart} onNavigate={onNavigate} />;
      case 'soft':
        return <SoftBinding onAddToCart={onAddToCart} onNavigate={onNavigate} />;
      case 'custom':
        return <CustomPrinting onAddToCart={onAddToCart} onNavigate={onNavigate} />;
      case 'color-custom':
        return <ColorCustomPages onAddToCart={onAddToCart} onNavigate={onNavigate} />;
      default:
        return (
          <div className="min-h-screen bg-gray-50 py-12">
            <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
              <div className="bg-white rounded-2xl shadow-xl p-12">
                <div className="w-24 h-24 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-6">
                  <GraduationCap className="w-12 h-12 text-gray-400" />
                </div>
                <h2 className="text-3xl font-bold text-gray-900 mb-4">Coming Soon!</h2>
                <p className="text-xl text-gray-600 mb-8">
                  This service is currently under development. Stay tuned for updates!
                </p>
                <button
                  onClick={() => onNavigate('contact')}
                  className="bg-blue-600 text-white px-8 py-3 rounded-lg font-semibold hover:bg-blue-700 transition-all duration-300 transform hover:scale-105"
                >
                  Contact Us for More Info
                </button>
              </div>
            </div>
          </div>
        );
    }
  };

  // If onAddToCart is provided, render the tabbed interface
  if (onAddToCart) {
    return (
      <div className="min-h-screen bg-gray-50">
        {/* Header */}
        <div className="bg-white shadow-sm border-b">
          <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
            <div className="text-center">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h1>
              <p className="text-xl text-gray-600 max-w-2xl mx-auto mb-8">
                Choose from our range of professional printing and binding services
              </p>

              {/* Tab Bar */}
              <div className="flex flex-wrap justify-center gap-2 bg-gray-100 p-2 rounded-2xl max-w-4xl mx-auto">
                {tabs.map((tab) => {
                  const Icon = tab.icon;
                  const isActive = activeTab === tab.id;
                  
                  return (
                    <button
                      key={tab.id}
                      onClick={() => tab.available && setActiveTab(tab.id)}
                      disabled={!tab.available}
                      className={`
                        flex items-center space-x-2 px-6 py-3 rounded-xl font-semibold text-sm
                        transition-all duration-300 transform
                        ${tab.available ? 'hover:scale-105' : 'opacity-50 cursor-not-allowed'}
                        ${getTabColorClasses(tab.color, isActive)}
                        ${isActive ? 'shadow-lg' : 'border'}
                      `}
                    >
                      <Icon className="w-4 h-4" />
                      <span>{tab.name}</span>
                      {!tab.available && (
                        <span className="text-xs bg-gray-200 text-gray-600 px-2 py-1 rounded-full ml-1">
                          Soon
                        </span>
                      )}
                    </button>
                  );
                })}
              </div>
            </div>
          </div>
        </div>

        {/* Tab Content */}
        <div className="transition-all duration-500 ease-in-out">
          {renderTabContent()}
        </div>
      </div>
    );
  }

  // Original Services overview page
  const services = [
    {
      name: 'Printing Service',
      icon: Printer,
      description: 'High-quality black & white and color printing with competitive rates',
      features: ['B&W Single: ₹1.5/page', 'B&W Double: ₹1.7/page', 'Color Single: ₹8/page', 'Color Double: ₹12/page'],
      color: 'blue',
      page: 'printing' as PageType,
    },
    {
      name: 'Spiral Binding',
      icon: BookOpen,
      description: 'Professional spiral binding service with flexible pricing based on page count',
      features: ['≤60 pages: ₹25', '61-100 pages: ₹30', '101-120 pages: ₹35', 'Extra pages: +₹5/20 pages'],
      color: 'green',
      page: 'spiral-binding' as PageType,
    },
    {
      name: 'Soft Binding',
      icon: FileText,
      description: 'Elegant soft cover binding combined with quality printing services',
      features: ['Print + Binding combo', 'All print types available', '₹25 binding charge', 'Professional finish'],
      color: 'purple',
      page: 'soft-binding' as PageType,
    },
    {
      name: 'Custom Printing',
      icon: Palette,
      description: 'Special layouts and compact printing solutions for unique requirements',
      features: ['4-in-1 layout', '8-in-1 micro printing', '9-in-1 micro printing', 'Single/Double side options'],
      color: 'orange',
      page: 'custom-printing' as PageType,
    },
  ];

  const colorClasses = {
    blue: {
      bg: 'from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700',
      light: 'bg-blue-50 border-blue-200',
      text: 'text-blue-600',
      icon: 'bg-blue-100 text-blue-600'
    },
    green: {
      bg: 'from-green-500 to-green-600 hover:from-green-600 hover:to-green-700',
      light: 'bg-green-50 border-green-200',
      text: 'text-green-600',
      icon: 'bg-green-100 text-green-600'
    },
    purple: {
      bg: 'from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700',
      light: 'bg-purple-50 border-purple-200',
      text: 'text-purple-600',
      icon: 'bg-purple-100 text-purple-600'
    },
    orange: {
      bg: 'from-orange-500 to-orange-600 hover:from-orange-600 hover:to-orange-700',
      light: 'bg-orange-50 border-orange-200',
      text: 'text-orange-600',
      icon: 'bg-orange-100 text-orange-600'
    }
  };

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
          <div className="text-center">
            <h1 className="text-4xl font-bold text-gray-900 mb-4">Our Services</h1>
            <p className="text-xl text-gray-600 max-w-2xl mx-auto">
              Professional printing and binding services tailored to meet all your document needs
            </p>
          </div>
        </div>
      </div>

      {/* Services Grid */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8">
          {services.map((service, index) => {
            const Icon = service.icon;
            const colors = colorClasses[service.color as keyof typeof colorClasses];

            return (
              <div
                key={service.name}
                className="bg-white rounded-2xl shadow-xl overflow-hidden hover:shadow-2xl transition-all duration-300 transform hover:-translate-y-1"
                style={{ animationDelay: `${index * 100}ms` }}
              >
                <div className={`h-2 bg-gradient-to-r ${colors.bg}`}></div>
                
                <div className="p-8">
                  <div className="flex items-center space-x-4 mb-6">
                    <div className={`w-16 h-16 rounded-full ${colors.icon} flex items-center justify-center`}>
                      <Icon className="w-8 h-8" />
                    </div>
                    <div>
                      <h3 className="text-2xl font-bold text-gray-900">{service.name}</h3>
                      <div className="flex items-center space-x-1 mt-1">
                        {[...Array(5)].map((_, i) => (
                          <Star key={i} className="w-4 h-4 text-yellow-400 fill-current" />
                        ))}
                        <span className="text-sm text-gray-500 ml-2">(4.9/5)</span>
                      </div>
                    </div>
                  </div>

                  <p className="text-gray-600 mb-6 text-lg leading-relaxed">
                    {service.description}
                  </p>

                  <div className={`border rounded-lg p-4 mb-6 ${colors.light}`}>
                    <h4 className="font-semibold text-gray-900 mb-3">Key Features:</h4>
                    <ul className="space-y-2">
                      {service.features.map((feature, idx) => (
                        <li key={idx} className="flex items-center space-x-2">
                          <div className={`w-2 h-2 rounded-full ${colors.text.replace('text-', 'bg-')}`}></div>
                          <span className="text-gray-700">{feature}</span>
                        </li>
                      ))}
                    </ul>
                  </div>

                  <button
                    onClick={() => onNavigate(service.page)}
                    className={`
                      w-full py-4 rounded-lg font-semibold text-white bg-gradient-to-r ${colors.bg} 
                      transition-all duration-300 transform hover:scale-105 
                      flex items-center justify-center space-x-2
                      animate-pulse hover:animate-none
                      shadow-lg hover:shadow-xl
                    `}
                  >
                    <span>Get Started</span>
                    <ArrowRight className="w-5 h-5" />
                  </button>
                </div>
              </div>
            );
          })}
        </div>

        {/* Additional Service */}
        <div className="mt-12">
          <div className="bg-gradient-to-r from-pink-500 to-rose-600 rounded-2xl shadow-xl overflow-hidden text-white">
            <div className="p-8">
              <div className="flex items-center space-x-4 mb-6">
                <div className="w-16 h-16 rounded-full bg-white bg-opacity-20 flex items-center justify-center">
                  <Palette className="w-8 h-8" />
                </div>
                <div>
                  <h3 className="text-2xl font-bold">Color Custom Pages</h3>
                  <p className="text-pink-100">Mix color and B&W printing for specific pages</p>
                </div>
              </div>

              <p className="text-pink-100 mb-6 text-lg">
                Perfect for documents where only certain pages need color printing. 
                Specify which pages should be in color and save money on the rest.
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-4 mb-6">
                <div className="bg-white bg-opacity-10 rounded-lg p-4">
                  <h4 className="font-semibold mb-2">Color Pages</h4>
                  <p className="text-sm text-pink-100">₹8 single / ₹12 double</p>
                </div>
                <div className="bg-white bg-opacity-10 rounded-lg p-4">
                  <h4 className="font-semibold mb-2">B&W Pages</h4>
                  <p className="text-sm text-pink-100">₹1.5 single / ₹1.7 double</p>
                </div>
              </div>

              <button
                onClick={() => onNavigate('color-custom' as PageType)}
                className="
                  w-full py-4 rounded-lg font-semibold bg-white text-pink-600 
                  hover:bg-pink-50 transition-all duration-300 transform hover:scale-105 
                  flex items-center justify-center space-x-2
                  animate-bounce hover:animate-none
                  shadow-lg hover:shadow-xl
                "
              >
                <span>Try Color Custom</span>
                <ArrowRight className="w-5 h-5" />
              </button>
            </div>
          </div>
        </div>

        {/* Why Choose Our Services */}
        <div className="mt-16 bg-white rounded-2xl shadow-xl p-8">
          <h2 className="text-2xl font-bold text-gray-900 text-center mb-8">Why Choose Our Services?</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Star className="w-6 h-6 text-blue-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Quality Guaranteed</h3>
              <p className="text-gray-600 text-sm">Premium quality materials and state-of-the-art equipment</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <ArrowRight className="w-6 h-6 text-green-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Fast Turnaround</h3>
              <p className="text-gray-600 text-sm">Quick processing and delivery without compromising quality</p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center mx-auto mb-4">
                <Palette className="w-6 h-6 text-purple-600" />
              </div>
              <h3 className="font-semibold text-gray-900 mb-2">Custom Solutions</h3>
              <p className="text-gray-600 text-sm">Tailored services to meet your specific requirements</p>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Services;