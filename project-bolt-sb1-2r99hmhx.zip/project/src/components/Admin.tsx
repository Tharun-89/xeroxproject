import React, { useState } from 'react';
import { Shield, Lock, Eye, Trash2, Filter, Calendar, Package, BarChart3 } from 'lucide-react';
import { CartItem, Order } from '../types';

interface AdminProps {
  cartItems: CartItem[];
  onClearAllOrders: () => void;
}

const Admin: React.FC<AdminProps> = ({ cartItems, onClearAllOrders }) => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [filterService, setFilterService] = useState('all');
  const [filterDate, setFilterDate] = useState('');

  const handleLogin = (e: React.FormEvent) => {
    e.preventDefault();
    
    if (username === 'Aishwarya' && password === 'aishwarya xerox@1999') {
      setIsLoggedIn(true);
    } else {
      alert('Invalid credentials!');
    }
  };

  const handleLogout = () => {
    setIsLoggedIn(false);
    setUsername('');
    setPassword('');
  };

  const formatDate = (date: Date) => {
    return new Intl.DateTimeFormat('en-IN', {
      year: 'numeric',
      month: 'short',
      day: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    }).format(date);
  };

  const getServiceColor = (serviceName: string) => {
    switch (serviceName) {
      case 'Printing':
        return 'bg-blue-100 text-blue-800 border-blue-200';
      case 'Spiral Binding':
        return 'bg-green-100 text-green-800 border-green-200';
      case 'Soft Binding':
        return 'bg-purple-100 text-purple-800 border-purple-200';
      case 'Custom Printing':
        return 'bg-orange-100 text-orange-800 border-orange-200';
      case 'Color Custom Pages':
        return 'bg-pink-100 text-pink-800 border-pink-200';
      default:
        return 'bg-gray-100 text-gray-800 border-gray-200';
    }
  };

  // Filter orders based on selected filters
  const filteredOrders = cartItems.filter(item => {
    const serviceMatch = filterService === 'all' || item.serviceName === filterService;
    const dateMatch = !filterDate || item.timestamp.toDateString() === new Date(filterDate).toDateString();
    return serviceMatch && dateMatch;
  });

  // Calculate statistics
  const totalRevenue = cartItems.reduce((sum, item) => sum + item.price, 0);
  const serviceStats = cartItems.reduce((acc, item) => {
    acc[item.serviceName] = (acc[item.serviceName] || 0) + 1;
    return acc;
  }, {} as Record<string, number>);

  if (!isLoggedIn) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-gray-900 to-gray-800 flex items-center justify-center py-12">
        <div className="bg-white rounded-2xl shadow-2xl p-8 w-full max-w-md">
          <div className="text-center mb-8">
            <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-4">
              <Shield className="w-8 h-8 text-gray-600" />
            </div>
            <h1 className="text-2xl font-bold text-gray-900">Admin Login</h1>
            <p className="text-gray-600 mt-2">Access the admin dashboard</p>
          </div>

          <form onSubmit={handleLogin} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Username
              </label>
              <input
                type="text"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter username"
                required
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-2">
                Password
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                className="w-full p-3 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                placeholder="Enter password"
                required
              />
            </div>

            <button
              type="submit"
              className="w-full bg-gradient-to-r from-blue-600 to-blue-700 text-white py-3 px-6 rounded-lg font-semibold hover:from-blue-700 hover:to-blue-800 transition-all duration-300 flex items-center justify-center space-x-2"
            >
              <Lock className="w-5 h-5" />
              <span>Login</span>
            </button>
          </form>

          <div className="mt-6 p-4 bg-yellow-50 border border-yellow-200 rounded-lg">
            <p className="text-sm text-yellow-800">
              <strong>Demo Credentials:</strong><br />
              Username: Aishwarya<br />
              Password: aishwarya xerox@1999
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <div className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
          <div className="flex justify-between items-center">
            <div className="flex items-center space-x-3">
              <div className="w-10 h-10 bg-blue-100 rounded-full flex items-center justify-center">
                <Shield className="w-6 h-6 text-blue-600" />
              </div>
              <div>
                <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
                <p className="text-sm text-gray-600">Welcome back, Aishwarya</p>
              </div>
            </div>
            <button
              onClick={handleLogout}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors"
            >
              Logout
            </button>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Statistics Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Orders</p>
                <p className="text-3xl font-bold text-gray-900">{cartItems.length}</p>
              </div>
              <div className="w-12 h-12 bg-blue-100 rounded-full flex items-center justify-center">
                <Package className="w-6 h-6 text-blue-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Total Revenue</p>
                <p className="text-3xl font-bold text-gray-900">₹{totalRevenue}</p>
              </div>
              <div className="w-12 h-12 bg-green-100 rounded-full flex items-center justify-center">
                <BarChart3 className="w-6 h-6 text-green-600" />
              </div>
            </div>
          </div>

          <div className="bg-white rounded-xl shadow-lg p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-gray-600">Avg Order Value</p>
                <p className="text-3xl font-bold text-gray-900">
                  ₹{cartItems.length > 0 ? Math.round(totalRevenue / cartItems.length) : 0}
                </p>
              </div>
              <div className="w-12 h-12 bg-purple-100 rounded-full flex items-center justify-center">
                <Eye className="w-6 h-6 text-purple-600" />
              </div>
            </div>
          </div>
        </div>

        {/* Service Statistics */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
          <h3 className="text-lg font-semibold text-gray-900 mb-4">Service Breakdown</h3>
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            {Object.entries(serviceStats).map(([service, count]) => (
              <div key={service} className={`p-4 rounded-lg border ${getServiceColor(service)}`}>
                <p className="font-semibold">{service}</p>
                <p className="text-2xl font-bold">{count}</p>
              </div>
            ))}
          </div>
        </div>

        {/* Filters and Actions */}
        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <div className="flex flex-col md:flex-row md:items-center md:justify-between space-y-4 md:space-y-0">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <Filter className="w-5 h-5 text-gray-500" />
                <span className="text-sm font-medium text-gray-700">Filters:</span>
              </div>
              
              <select
                value={filterService}
                onChange={(e) => setFilterService(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              >
                <option value="all">All Services</option>
                <option value="Printing">Printing</option>
                <option value="Spiral Binding">Spiral Binding</option>
                <option value="Soft Binding">Soft Binding</option>
                <option value="Custom Printing">Custom Printing</option>
                <option value="Color Custom Pages">Color Custom Pages</option>
              </select>

              <input
                type="date"
                value={filterDate}
                onChange={(e) => setFilterDate(e.target.value)}
                className="border border-gray-300 rounded-lg px-3 py-2 focus:ring-2 focus:ring-blue-500 focus:border-transparent"
              />
            </div>

            <button
              onClick={onClearAllOrders}
              className="bg-red-600 text-white px-4 py-2 rounded-lg hover:bg-red-700 transition-colors flex items-center space-x-2"
            >
              <Trash2 className="w-4 h-4" />
              <span>Delete All Orders</span>
            </button>
          </div>
        </div>

        {/* Orders List */}
        <div className="bg-white rounded-xl shadow-lg overflow-hidden">
          <div className="p-6 border-b border-gray-200">
            <h2 className="text-xl font-semibold text-gray-900">
              Orders ({filteredOrders.length})
            </h2>
          </div>

          {filteredOrders.length === 0 ? (
            <div className="text-center py-12">
              <Package className="w-16 h-16 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No orders found matching your filters</p>
            </div>
          ) : (
            <div className="divide-y divide-gray-200">
              {filteredOrders.map((item) => (
                <div key={item.id} className="p-6 hover:bg-gray-50 transition-colors">
                  <div className="flex justify-between items-start">
                    <div className="flex-1">
                      <div className="flex items-center space-x-3 mb-2">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium border ${getServiceColor(item.serviceName)}`}>
                          {item.serviceName}
                        </span>
                        <span className="text-sm text-gray-500 flex items-center">
                          <Calendar className="w-4 h-4 mr-1" />
                          {formatDate(item.timestamp)}
                        </span>
                      </div>

                      <h3 className="font-semibold text-gray-900 mb-1">{item.fileName}</h3>
                      <p className="text-sm text-gray-600 mb-2">{item.pageCount} pages</p>

                      <div className="text-sm text-gray-600">
                        {item.serviceName === 'Printing' && (
                          <span>
                            {item.options.printType?.replace('-', ' ').toUpperCase()} • {item.options.copies} copies
                          </span>
                        )}
                        {item.serviceName === 'Spiral Binding' && (
                          <span>
                            {item.options.isDoubleSide ? 'Double-sided' : 'Single-sided'} • {item.options.copies} copies
                          </span>
                        )}
                        {item.serviceName === 'Soft Binding' && (
                          <span>
                            {item.options.printType?.replace('-', ' ').toUpperCase()} • {item.options.copies} copies
                          </span>
                        )}
                        {item.serviceName === 'Custom Printing' && (
                          <span>
                            {item.options.customType} • {item.options.isDoubleSide ? 'Double' : 'Single'} • {item.options.copies} copies
                          </span>
                        )}
                        {item.serviceName === 'Color Custom Pages' && (
                          <span>
                            {item.options.colorPages} color pages • {item.options.printType} side • {item.options.copies} copies
                          </span>
                        )}
                      </div>
                    </div>

                    <div className="text-right">
                      <p className="text-xl font-bold text-gray-900">₹{item.price}</p>
                      <p className="text-sm text-gray-500">Order #{item.id.slice(-6)}</p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
};

export default Admin;