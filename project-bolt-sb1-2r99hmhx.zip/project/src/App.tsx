import React, { useState } from 'react';
import Layout from './components/Layout';
import Home from './components/Home';
import Services from './components/Services';
import About from './components/About';
import ContactUs from './components/ContactUs';
import Cart from './components/Cart';
import Admin from './components/Admin';
import AdminDashboard from './components/AdminDashboard';
import PrintingService from './components/services/PrintingService';
import SpiralBinding from './components/services/SpiralBinding';
import SoftBinding from './components/services/SoftBinding';
import CustomPrinting from './components/services/CustomPrinting';
import ColorCustomPages from './components/services/ColorCustomPages';
import { PageType, CartItem } from './types';

function App() {
  const [currentPage, setCurrentPage] = useState<PageType>('home');
  const [cartItems, setCartItems] = useState<CartItem[]>([]);

  const handleNavigate = (page: PageType) => {
    setCurrentPage(page);
  };

  const handleAddToCart = (item: CartItem) => {
    setCartItems(prev => [...prev, item]);
  };

  const handleRemoveFromCart = (id: string) => {
    setCartItems(prev => prev.filter(item => item.id !== id));
  };

  const handleClearCart = () => {
    setCartItems([]);
  };

  const renderCurrentPage = () => {
    switch (currentPage) {
      case 'home':
        return <Home onNavigate={handleNavigate} />;
      case 'services':
        return <Services onNavigate={handleNavigate} onAddToCart={handleAddToCart} />;
      case 'about':
        return <About />;
      case 'contact':
        return <ContactUs />;
      case 'cart':
        return (
          <Cart
            cartItems={cartItems}
            onRemoveItem={handleRemoveFromCart}
            onClearCart={handleClearCart}
          />
        );
      case 'admin':
        return (
          <Admin
            cartItems={cartItems}
            onClearAllOrders={handleClearCart}
          />
        );
      case 'admin-dashboard':
        return <AdminDashboard />;
      case 'printing':
        return <PrintingService onAddToCart={handleAddToCart} onNavigate={handleNavigate} />;
      case 'spiral-binding':
        return <SpiralBinding onAddToCart={handleAddToCart} onNavigate={handleNavigate} />;
      case 'soft-binding':
        return <SoftBinding onAddToCart={handleAddToCart} onNavigate={handleNavigate} />;
      case 'custom-printing':
        return <CustomPrinting onAddToCart={handleAddToCart} onNavigate={handleNavigate} />;
      case 'color-custom':
        return <ColorCustomPages onAddToCart={handleAddToCart} onNavigate={handleNavigate} />;
      default:
        return <Home onNavigate={handleNavigate} />;
    }
  };

  return (
    <Layout
      currentPage={currentPage}
      onNavigate={handleNavigate}
      cartItemCount={cartItems.length}
    >
      {renderCurrentPage()}
    </Layout>
  );
}

export default App;