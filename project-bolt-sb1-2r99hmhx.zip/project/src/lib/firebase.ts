import { initializeApp } from 'firebase/app';
import { getFirestore, collection, addDoc, getDocs, query, orderBy, where, Timestamp } from 'firebase/firestore';
import { getStorage, ref, uploadBytes, getDownloadURL } from 'firebase/storage';

const firebaseConfig = {
  apiKey: "AIzaSyBazpndzSPjHpWnSpOyf05yHjmU4xrZHNg",
  authDomain: "orders-8abd7.firebaseapp.com",
  projectId: "orders-8abd7",
  storageBucket: "orders-8abd7.firebasestorage.app",
  messagingSenderId: "248370198623",
  appId: "1:248370198623:web:e1e9a7bdd3eca151c603ea"
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);

// Initialize Firestore
export const db = getFirestore(app);

// Initialize Storage
export const storage = getStorage(app);

// Database types
export interface Order {
  id: string;
  name: string;
  phone: string;
  service: string;
  side_type: string;
  color_type: string;
  copies: number;
  pages: number;
  total_price: number;
  file_url?: string;
  timestamp: Date;
  created_at: Date;
}

// Helper functions for Firestore operations
export const ordersCollection = collection(db, 'orders');

// Save to Firebase Firestore (collection: orders)
export const addOrder = async (orderData: Omit<Order, 'id' | 'created_at'>) => {
  try {
    const docRef = await addDoc(ordersCollection, {
      ...orderData,
      timestamp: Timestamp.fromDate(orderData.timestamp),
      created_at: Timestamp.now()
    });
    return docRef.id;
  } catch (error) {
    console.error('Error adding order:', error);
    throw error;
  }
};

export const getOrders = async () => {
  try {
    const q = query(ordersCollection, orderBy('created_at', 'desc'));
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      timestamp: doc.data().timestamp?.toDate() || new Date(),
      created_at: doc.data().created_at?.toDate() || new Date()
    })) as Order[];
  } catch (error) {
    console.error('Error fetching orders:', error);
    throw error;
  }
};

export const getOrdersByService = async (service: string) => {
  try {
    const q = query(
      ordersCollection, 
      where('service', '==', service),
      orderBy('created_at', 'desc')
    );
    const querySnapshot = await getDocs(q);
    
    return querySnapshot.docs.map(doc => ({
      id: doc.id,
      ...doc.data(),
      timestamp: doc.data().timestamp?.toDate() || new Date(),
      created_at: doc.data().created_at?.toDate() || new Date()
    })) as Order[];
  } catch (error) {
    console.error('Error fetching orders by service:', error);
    throw error;
  }
};

export const uploadFile = async (file: File, path: string) => {
  try {
    const storageRef = ref(storage, path);
    const snapshot = await uploadBytes(storageRef, file);
    const downloadURL = await getDownloadURL(snapshot.ref);
    return downloadURL;
  } catch (error) {
    console.error('Error uploading file:', error);
    throw error;
  }
};